# L08-S06-tarea-01 · Confirmar y revertir transacciones

![Resumen del encargo y comprobación de Confirmar y revertir transacciones](infografia.webp)

## Qué debes hacer

Una actualización revertida deja el estado original. En el proyecto añade el movimiento en la misma transacción.

Implementa el comportamiento de esta ficha en `src/main/java` y resuelve los diez ejercicios de abajo. Usa **Java 21** y abre el `pom.xml` desde tu IDE. El código contiene firmas pendientes que lanzan `UnsupportedOperationException` hasta que las completes. Conserva los nombres que usan las pruebas.

## Ejemplo orientativo

Reserva una plaza y registra la operación en un historial. Si falla el segundo paso, predice qué debe ocurrir con la primera escritura.

## Primera comprobación automática

El POM incluye el driver SQLite. Cierra conexiones y resultados mediante try-with-resources. Usa una base nueva para cada comprobación.

Resultado de referencia:

```text
5
```

Ejecuta `mvn test` desde la carpeta del proyecto. La prueba suministrada comprueba el comportamiento descrito en esta sección y debe fallar mientras esté pendiente. Si el ejercicio consiste en compilar, lanzar o depurar, registra también el comando, la salida y la causa que observaste.

## Dossier de diez ejercicios

Desarrolla cada ejercicio en un método o clase propia, o amplía el programa cuando el enunciado lo requiera. Para cada uno, anota una entrada concreta y el resultado esperado antes de ejecutarlo. Añade una prueba JUnit para la lógica nueva. En los últimos tres, incluye también un caso límite o de error.

1. Inicia una transacción.
2. Confirma una actualización.
3. Revierte una actualización.
4. Registra una salida.
5. Descuenta unidades en la misma transacción.
6. Comprueba el total con dos operaciones.
7. Distingue error y confirmación.
8. Fuerza fallo en la segunda operación.
9. Comprueba stock insuficiente.
10. Demuestra en dos bases el resultado de commit y rollback.

## Entrega

- Ejecuta `mvn test` y `mvn javadoc:javadoc`. Entrega el código, las pruebas y una tabla con entrada, resultado esperado y resultado obtenido.

## Cómo documentar tu código con Javadoc

Añade un bloque Javadoc encima de cada método y constructor que completes, incluido `main` si existe.
Describe qué hace, qué espera recibir y qué resultado promete. Indica si modifica un objeto,
un array o un fichero. Revisa también que la descripción de cada clase explique su responsabilidad.

- Usa `@param` con el nombre de cada parámetro y explica qué representa y qué valores admite.
- Usa `@return` si el método devuelve un valor. En un método `void` o en un constructor puedes omitirlo.
- Usa `@throws` para explicar qué condición provoca cada excepción que forme parte del contrato.
- Si `main` no utiliza los argumentos de la terminal, indícalo al documentar `args`.

**Modelo para un método ajeno a la tarea**

```java
/**
 * Devuelve el número de páginas de un cuaderno.
 * @param hojas número de hojas del cuaderno, mayor o igual que cero
 * @return número de páginas del cuaderno
 * @throws IllegalArgumentException si el número de hojas es negativo
 */
```

Genera la documentación con `mvn javadoc:javadoc`. Abre `target/site/apidocs/index.html` y comprueba
que se entiende el contrato sin leer el cuerpo del método.
