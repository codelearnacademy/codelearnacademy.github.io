/** Punto de partida del dossier «Encapsular el acceso en un DAO». */
public class Main {
    public static void main(String[] args) throws Exception {
        throw new UnsupportedOperationException("Implementa los requisitos del README");
    }
}
