# Préstamos en ObjectDB

Abre el proyecto Maven con JDK 21 y deja que Maven descargue el gestor embebido.
La configuración emplea la variante Jakarta de ObjectDB. Consulta [su guía de instalación](https://www.objectdb.com/download).

Ejecuta con una base nueva:

```bash
mvn compile exec:java -Dexec.args="prestamos.odb crear"
mvn exec:java -Dexec.args="prestamos.odb leer"
mvn exec:java -Dexec.args="prestamos.odb rollback"
mvn exec:java -Dexec.args="prestamos.odb leer"
mvn exec:java -Dexec.args="prestamos.odb cerrar"
mvn exec:java -Dexec.args="prestamos.odb leer"
mvn exec:java -Dexec.args="prestamos.odb borrar"
mvn exec:java -Dexec.args="prestamos.odb leer"
mvn exec:java -Dexec.args="prestamos.odb material"
```

Las lecturas deben mostrar ABIERTO, ABIERTO, CERRADO y finalmente Préstamo ausente.
Mientras exista, el préstamo debe mostrar MAT-01 x 2. El material debe seguir presente.
Como ampliación, añade una consulta por estado y compárala con la búsqueda por identidad.
