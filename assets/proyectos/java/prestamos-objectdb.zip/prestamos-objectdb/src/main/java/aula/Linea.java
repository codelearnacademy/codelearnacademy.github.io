package aula;

import jakarta.persistence.*;

@Embeddable
public class Linea {
    @ManyToOne(optional = false) private Material material;
    private int cantidad;

    protected Linea() {}
    public Linea(Material material, int cantidad) {
        if (cantidad <= 0) throw new IllegalArgumentException("Cantidad inválida");
        this.material = material;
        this.cantidad = cantidad;
    }
    public String detalle() { return material.codigo() + " x " + cantidad; }
}
