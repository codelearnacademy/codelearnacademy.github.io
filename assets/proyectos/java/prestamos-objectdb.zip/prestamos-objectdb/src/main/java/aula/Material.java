package aula;

import jakarta.persistence.*;

@Entity
public class Material {
    @Id private String codigo;
    protected Material() {}
    public Material(String codigo) { this.codigo = codigo; }
    public String codigo() { return codigo; }
}
