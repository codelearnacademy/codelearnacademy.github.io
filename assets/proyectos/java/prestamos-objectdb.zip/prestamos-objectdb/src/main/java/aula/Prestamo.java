package aula;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Prestamo {
    @Id private String id;
    private String estado;
    @ElementCollection private List<Linea> lineas = new ArrayList<>();

    protected Prestamo() {}
    public Prestamo(String id, Material material) {
        this.id = id;
        estado = "ABIERTO";
        lineas.add(new Linea(material, 2));
    }
    public void cerrar() { estado = "CERRADO"; }
    public String detalle() { return estado + " | " + lineas.getFirst().detalle(); }
}
