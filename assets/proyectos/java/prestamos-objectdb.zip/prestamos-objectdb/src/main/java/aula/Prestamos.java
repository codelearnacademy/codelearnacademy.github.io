package aula;

import jakarta.persistence.*;

public class Prestamos {
    public static void main(String[] args) {
        if (args.length != 2 || !args[0].endsWith(".odb")) {
            System.out.println("Uso: archivo.odb crear|leer|cerrar|rollback|borrar|material");
            return;
        }
        var fabrica = Persistence.createEntityManagerFactory(args[0]);
        try {
            var gestor = fabrica.createEntityManager();
            try {
                operar(gestor, args[1]);
            } finally {
                gestor.close();
            }
        } finally {
            fabrica.close();
        }
    }

    private static void operar(EntityManager gestor, String comando) {
        if (comando.equals("material")) {
            System.out.println(gestor.find(Material.class, "MAT-01") != null ? "Material presente" : "Material ausente");
            return;
        }
        var prestamo = gestor.find(Prestamo.class, "P1");
        if (comando.equals("leer")) {
            System.out.println(prestamo == null ? "Préstamo ausente" : prestamo.detalle());
            return;
        }
        var tx = gestor.getTransaction();
        tx.begin();
        try {
            switch (comando) {
                case "crear" -> {
                    var material = gestor.find(Material.class, "MAT-01");
                    if (material == null) {
                        material = new Material("MAT-01");
                        gestor.persist(material);
                    }
                    gestor.persist(new Prestamo("P1", material));
                }
                case "cerrar", "rollback" -> obligatorio(prestamo).cerrar();
                case "borrar" -> gestor.remove(obligatorio(prestamo));
                default -> throw new IllegalArgumentException("Comando desconocido");
            }
            if (comando.equals("rollback")) tx.rollback();
            else tx.commit();
        } catch (RuntimeException error) {
            if (tx.isActive()) tx.rollback();
            throw error;
        }
    }

    private static Prestamo obligatorio(Prestamo prestamo) {
        if (prestamo == null) throw new IllegalArgumentException("No existe P1");
        return prestamo;
    }
}
