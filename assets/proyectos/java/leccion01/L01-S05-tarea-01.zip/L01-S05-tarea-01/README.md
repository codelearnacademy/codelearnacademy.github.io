# L01-S05-tarea-01 · Inspeccionar el bytecode

![Resumen del encargo y comprobación de Inspeccionar el bytecode](infografia.webp)

## Qué debes hacer

Compila y ejecuta javap -c Main para ver las instrucciones del método main.

Implementa el comportamiento de esta ficha en `src/main/java` y resuelve los diez ejercicios de abajo. Usa **Java 21** y abre el `pom.xml` desde tu IDE. El código contiene firmas pendientes que lanzan `UnsupportedOperationException` hasta que las completes. Conserva los nombres que usan las pruebas.

## Ejemplo orientativo

Inspecciona mentalmente un programa auxiliar que llama a un método llamado saludar. En la salida de javap, busca primero el nombre del método para identificar la llamada.

## Primera comprobación automática


Resultado de referencia:

```text
Hola
```

Ejecuta `mvn test` desde la carpeta del proyecto. La prueba suministrada comprueba el comportamiento descrito en esta sección y debe fallar mientras esté pendiente. Si el ejercicio consiste en compilar, lanzar o depurar, registra también el comando, la salida y la causa que observaste.

## Dossier de diez ejercicios

Desarrolla cada ejercicio en un método o clase propia, o amplía el programa cuando el enunciado lo requiera. Para cada uno, anota una entrada concreta y el resultado esperado antes de ejecutarlo. Añade una prueba JUnit para la lógica nueva. En los últimos tres, incluye también un caso límite o de error.

1. Inspecciona un println.
2. Inspecciona dos println.
3. Localiza la carga de un literal.
4. Compara dos literales numéricos.
5. Inspecciona una suma sencilla.
6. Localiza la llamada a un método propio.
7. Contrasta println de texto y de entero.
8. Detecta un class que no corresponde al fuente.
9. Corrige el classpath de javap.
10. Relaciona tres fragmentos fuente con sus instrucciones desensambladas.

## Entrega

- Ejecuta `mvn test` y `mvn javadoc:javadoc`. Entrega el código, las pruebas y una tabla con entrada, resultado esperado y resultado obtenido.

## Cómo documentar tu código con Javadoc

Añade un bloque Javadoc encima de cada método y constructor que completes, incluido `main` si existe.
Describe qué hace, qué espera recibir y qué resultado promete. Indica si modifica un objeto,
un array o un fichero. Revisa también que la descripción de cada clase explique su responsabilidad.

- Usa `@param` con el nombre de cada parámetro y explica qué representa y qué valores admite.
- Usa `@return` si el método devuelve un valor. En un método `void` o en un constructor puedes omitirlo.
- Usa `@throws` para explicar qué condición provoca cada excepción que forme parte del contrato.
- Si `main` no utiliza los argumentos de la terminal, indícalo al documentar `args`.

**Modelo para un método ajeno a la tarea**

```java
/**
 * Devuelve el número de páginas de un cuaderno.
 * @param hojas número de hojas del cuaderno, mayor o igual que cero
 * @return número de páginas del cuaderno
 * @throws IllegalArgumentException si el número de hojas es negativo
 */
```

Genera la documentación con `mvn javadoc:javadoc`. Abre `target/site/apidocs/index.html` y comprueba
que se entiende el contrato sin leer el cuerpo del método.
