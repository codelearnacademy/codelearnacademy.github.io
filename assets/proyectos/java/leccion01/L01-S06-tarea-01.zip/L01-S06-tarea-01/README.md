# L01-S06-tarea-01 · Diagnosticar errores

![Resumen del encargo y comprobación de Diagnosticar errores](infografia.webp)

## Qué debes hacer

Compila primero. Guarda una copia como Otro.java e intenta compilarla para reproducir el error de nombre.

Implementa el comportamiento de esta ficha en `src/main/java` y resuelve los diez ejercicios de abajo. Usa **Java 21** y abre el `pom.xml` desde tu IDE. El código contiene firmas pendientes que lanzan `UnsupportedOperationException` hasta que las completes. Conserva los nombres que usan las pruebas.

## Ejemplo orientativo

Supón que el compilador marca la línea posterior a una cadena sin cerrar. Revisa la línea anterior y anota qué cambio probarías antes de volver a compilar.

## Primera comprobación automática


Resultado de referencia:

```text
Clase Main
```

Ejecuta `mvn test` desde la carpeta del proyecto. La prueba suministrada comprueba el comportamiento descrito en esta sección y debe fallar mientras esté pendiente. Si el ejercicio consiste en compilar, lanzar o depurar, registra también el comando, la salida y la causa que observaste.

## Dossier de diez ejercicios

Desarrolla cada ejercicio en un método o clase propia, o amplía el programa cuando el enunciado lo requiera. Para cada uno, anota una entrada concreta y el resultado esperado antes de ejecutarlo. Añade una prueba JUnit para la lógica nueva. En los últimos tres, incluye también un caso límite o de error.

1. Corrige un punto y coma ausente.
2. Corrige un literal sin cerrar.
3. Corrige una llave extra.
4. Corrige el nombre mismatched de clase y archivo.
5. Corrige una llamada a println mal escrita.
6. Distingue error al compilar de clase ausente al ejecutar.
7. Reproduce y resuelve un class obsoleto.
8. Localiza el primer error entre varios diagnósticos.
9. Corrige la configuración de lanzamiento de una clase válida.
10. Prepara una secuencia reproducible de tres fallos y sus correcciones.

## Entrega

- Ejecuta `mvn test` y `mvn javadoc:javadoc`. Entrega el código, las pruebas y una tabla con entrada, resultado esperado y resultado obtenido.

## Cómo documentar tu código con Javadoc

Añade un bloque Javadoc encima de cada método y constructor que completes, incluido `main` si existe.
Describe qué hace, qué espera recibir y qué resultado promete. Indica si modifica un objeto,
un array o un fichero. Revisa también que la descripción de cada clase explique su responsabilidad.

- Usa `@param` con el nombre de cada parámetro y explica qué representa y qué valores admite.
- Usa `@return` si el método devuelve un valor. En un método `void` o en un constructor puedes omitirlo.
- Usa `@throws` para explicar qué condición provoca cada excepción que forme parte del contrato.
- Si `main` no utiliza los argumentos de la terminal, indícalo al documentar `args`.

**Modelo para un método ajeno a la tarea**

```java
/**
 * Devuelve el número de páginas de un cuaderno.
 * @param hojas número de hojas del cuaderno, mayor o igual que cero
 * @return número de páginas del cuaderno
 * @throws IllegalArgumentException si el número de hojas es negativo
 */
```

Genera la documentación con `mvn javadoc:javadoc`. Abre `target/site/apidocs/index.html` y comprueba
que se entiende el contrato sin leer el cuerpo del método.
