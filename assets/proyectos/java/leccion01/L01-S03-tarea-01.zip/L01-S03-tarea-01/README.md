# L01-S03-tarea-01 · Compilar y ejecutar

![Resumen del encargo y comprobación de Compilar y ejecutar](infografia.webp)

## Qué debes hacer

Guarda Main.java. Ejecuta javac Main.java y luego java Main: el compilador crea Main.class.

Implementa el comportamiento de esta ficha en `src/main/java` y resuelve los diez ejercicios de abajo. Usa **Java 21** y abre el `pom.xml` desde tu IDE. El código contiene firmas pendientes que lanzan `UnsupportedOperationException` hasta que las completes. Conserva los nombres que usan las pruebas.

## Ejemplo orientativo

Imagina que Ticket.java imprime «Hola». Tras compilarlo, busca Ticket.class. Cambia el texto y predice si ejecutar el archivo compilado anterior mostrará el cambio.

## Primera comprobación automática


Resultado de referencia:

```text
1250
```

Ejecuta `mvn test` desde la carpeta del proyecto. La prueba suministrada comprueba el comportamiento descrito en esta sección y debe fallar mientras esté pendiente. Si el ejercicio consiste en compilar, lanzar o depurar, registra también el comando, la salida y la causa que observaste.

## Dossier de diez ejercicios

Desarrolla cada ejercicio en un método o clase propia, o amplía el programa cuando el enunciado lo requiera. Para cada uno, anota una entrada concreta y el resultado esperado antes de ejecutarlo. Añade una prueba JUnit para la lógica nueva. En los últimos tres, incluye también un caso límite o de error.

1. Calcula 5 por 250.
2. Muestra el importe y sus unidades.
3. Compila dos mensajes consecutivos.
4. Compara la salida antes y después de recompilar.
5. Genera Main.class en out y ejecútalo.
6. Compila dos archivos que colaboran.
7. Ejecuta desde la carpeta padre con classpath.
8. Corrige java Main.class.
9. Diagnostica una clase ausente del classpath.
10. Entrega código y comandos para reproducir una ficha compilada.

## Entrega

- Ejecuta `mvn test` y `mvn javadoc:javadoc`. Entrega el código, las pruebas y una tabla con entrada, resultado esperado y resultado obtenido.

## Cómo documentar tu código con Javadoc

Añade un bloque Javadoc encima de cada método y constructor que completes, incluido `main` si existe.
Describe qué hace, qué espera recibir y qué resultado promete. Indica si modifica un objeto,
un array o un fichero. Revisa también que la descripción de cada clase explique su responsabilidad.

- Usa `@param` con el nombre de cada parámetro y explica qué representa y qué valores admite.
- Usa `@return` si el método devuelve un valor. En un método `void` o en un constructor puedes omitirlo.
- Usa `@throws` para explicar qué condición provoca cada excepción que forme parte del contrato.
- Si `main` no utiliza los argumentos de la terminal, indícalo al documentar `args`.

**Modelo para un método ajeno a la tarea**

```java
/**
 * Devuelve el número de páginas de un cuaderno.
 * @param hojas número de hojas del cuaderno, mayor o igual que cero
 * @return número de páginas del cuaderno
 * @throws IllegalArgumentException si el número de hojas es negativo
 */
```

Genera la documentación con `mvn javadoc:javadoc`. Abre `target/site/apidocs/index.html` y comprueba
que se entiende el contrato sin leer el cuerpo del método.
