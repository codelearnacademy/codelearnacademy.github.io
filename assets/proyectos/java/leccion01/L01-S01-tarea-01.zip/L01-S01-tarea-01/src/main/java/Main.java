/** Punto de partida del dossier «Configurar el JDK y el IDE». */
public class Main {
    public static void main(String[] args) throws Exception {
        throw new UnsupportedOperationException("Implementa los requisitos del README");
    }
}
