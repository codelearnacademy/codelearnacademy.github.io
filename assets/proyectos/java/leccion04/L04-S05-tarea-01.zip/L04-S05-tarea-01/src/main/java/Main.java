/** Punto de partida del dossier «Métodos estáticos y de instancia». */
public class Main {
    public static void main(String[] args) throws Exception {
        throw new UnsupportedOperationException("Implementa los requisitos del README");
    }
}
