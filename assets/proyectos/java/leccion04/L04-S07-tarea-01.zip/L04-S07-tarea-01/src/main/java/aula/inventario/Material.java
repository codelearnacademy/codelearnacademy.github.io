package aula.inventario;

/** Modelo de un material de inventario. */
public final class Material {
    private final int unidades;

    public Material(int unidades) { throw new UnsupportedOperationException("Implementa el contrato del README"); }
    public Material retirar(int cantidad) { throw new UnsupportedOperationException("Implementa el contrato del README"); }
    public int unidades() { throw new UnsupportedOperationException("Implementa el contrato del README"); }
}
