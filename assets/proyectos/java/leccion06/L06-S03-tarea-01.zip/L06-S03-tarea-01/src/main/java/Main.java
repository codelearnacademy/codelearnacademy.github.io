/** Punto de partida del dossier «Recorrer listas con Iterator». */
public class Main {
    public static void main(String[] args) throws Exception {
        throw new UnsupportedOperationException("Implementa los requisitos del README");
    }
}
