import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

class MainTest {
    @Test
    void verificaElEjemploInicial() throws Exception {
        
        var salida = new ByteArrayOutputStream();
        var errores = new ByteArrayOutputStream();
        var original = System.out;
        var errorOriginal = System.err;
        var entradaOriginal = System.in;
        try {
            System.setOut(new PrintStream(salida, true, StandardCharsets.UTF_8));
            System.setErr(new PrintStream(errores, true, StandardCharsets.UTF_8));
            System.setIn(new ByteArrayInputStream("".getBytes(StandardCharsets.UTF_8)));
            Main.main(new String[0]);
        } finally {
            System.setOut(original);
            System.setErr(errorOriginal);
            System.setIn(entradaOriginal);
        }
        assertEquals("4", salida.toString(StandardCharsets.UTF_8).replace("\r\n", "\n").strip());
        assertEquals("", errores.toString(StandardCharsets.UTF_8).strip());
    }

}
