/** Punto de partida del dossier «Leer y modificar JSON y XML». */
public class Main {
    public static void main(String[] args) throws Exception {
        throw new UnsupportedOperationException("Implementa los requisitos del README");
    }
}
