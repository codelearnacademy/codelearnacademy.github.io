/** Punto de partida del dossier «Probar y documentar una jerarquía». */
public class Main {
    public static void main(String[] args) throws Exception {
        throw new UnsupportedOperationException("Implementa los requisitos del README");
    }
}
