/** Punto de partida del dossier «Sobrescritura y polimorfismo». */
public class Main {
    public static void main(String[] args) throws Exception {
        throw new UnsupportedOperationException("Implementa los requisitos del README");
    }
}
