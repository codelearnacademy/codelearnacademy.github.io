/** Punto de partida del dossier «Constructores y super». */
public class Main {
    public static void main(String[] args) throws Exception {
        throw new UnsupportedOperationException("Implementa los requisitos del README");
    }
}
