# L03-S07-tarea-01 · Depurar con puntos de interrupción

![Resumen del encargo y comprobación de Depurar con puntos de interrupción](infografia.webp)

## Qué debes hacer

Coloca un breakpoint en la suma, observa i y total, y cambia el límite para incluir la tercera unidad.

Implementa el comportamiento de esta ficha en `src/main/java` y resuelve los diez ejercicios de abajo. Usa **Java 21** y abre el `pom.xml` desde tu IDE. El código contiene firmas pendientes que lanzan `UnsupportedOperationException` hasta que las completes. Conserva los nombres que usan las pruebas.

## Ejemplo orientativo

Si un contador debería recorrer los valores 1, 2 y 3, pon un punto de interrupción en el cuerpo. Compara las visitas esperadas con las que registra tu ejecución.

## Primera comprobación automática


Resultado de referencia:

```text
500
```

Ejecuta `mvn test` desde la carpeta del proyecto. La prueba suministrada comprueba el comportamiento descrito en esta sección y debe fallar mientras esté pendiente. Si el ejercicio consiste en compilar, lanzar o depurar, registra también el comando, la salida y la causa que observaste.

## Dossier de diez ejercicios

Desarrolla cada ejercicio en un método o clase propia, o amplía el programa cuando el enunciado lo requiera. Para cada uno, anota una entrada concreta y el resultado esperado antes de ejecutarlo. Añade una prueba JUnit para la lógica nueva. En los últimos tres, incluye también un caso límite o de error.

1. Inspecciona el índice inicial.
2. Anota el acumulador en cada vuelta.
3. Predice el valor al salir del bucle.
4. Corrige el límite estricto.
5. Inspecciona una condición antes de entrar.
6. Compara la ejecución con cero y una unidad.
7. Depura una suma que reinicia el acumulador.
8. Localiza un índice fuera de rango.
9. Comprueba la corrección en tres entradas.
10. Entrega traza antes y después de reparar un total erróneo.

## Entrega

- Ejecuta `mvn test` y `mvn javadoc:javadoc`. Entrega el código, las pruebas y una tabla con entrada, resultado esperado y resultado obtenido.

## Cómo documentar tu código con Javadoc

Añade un bloque Javadoc encima de cada método y constructor que completes, incluido `main` si existe.
Describe qué hace, qué espera recibir y qué resultado promete. Indica si modifica un objeto,
un array o un fichero. Revisa también que la descripción de cada clase explique su responsabilidad.

- Usa `@param` con el nombre de cada parámetro y explica qué representa y qué valores admite.
- Usa `@return` si el método devuelve un valor. En un método `void` o en un constructor puedes omitirlo.
- Usa `@throws` para explicar qué condición provoca cada excepción que forme parte del contrato.
- Si `main` no utiliza los argumentos de la terminal, indícalo al documentar `args`.

**Modelo para un método ajeno a la tarea**

```java
/**
 * Devuelve el número de páginas de un cuaderno.
 * @param hojas número de hojas del cuaderno, mayor o igual que cero
 * @return número de páginas del cuaderno
 * @throws IllegalArgumentException si el número de hojas es negativo
 */
```

Genera la documentación con `mvn javadoc:javadoc`. Abre `target/site/apidocs/index.html` y comprueba
que se entiende el contrato sin leer el cuerpo del método.
