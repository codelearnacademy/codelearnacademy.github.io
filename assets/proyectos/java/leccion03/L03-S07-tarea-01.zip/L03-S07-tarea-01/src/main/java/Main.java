/** Punto de partida del dossier «Depurar con puntos de interrupción». */
public class Main {
    public static void main(String[] args) throws Exception {
        throw new UnsupportedOperationException("Implementa los requisitos del README");
    }
}
