# Recorrer un array · Inventario de aula

![Resumen del encargo y comprobación de Recorrer un array](infografia.webp)

Necesitas JDK 21 y Maven. Abre el archivo pom.xml en el IDE o ejecuta desde esta carpeta:

```bash
java -version
mvn -version
mvn test
```

Implementa los métodos de InventarioArrays sin cambiar sus firmas. El proyecto inicial
contiene únicamente los contratos pendientes de implementar. Es normal
que las pruebas fallen hasta completar los ejercicios. Las entradas de stock son
arrays no nulos con cantidades no negativas. No modifiques las pruebas.

Para ejecutar solo una prueba, por ejemplo el ejercicio 03:

```bash
mvn -Dtest=InventarioArraysTest#ejercicio03 test
```

## Ejemplo guiado

En el array con existencias 5, 0 y 3, el recorrido acumula primero 5, luego 5 y
finalmente 8. El primer agotado se encuentra en la posición 1. Abre la subsección
«Recorrer un array» en la ruta para consultar el código y la infografía.

## Ejemplo orientativo

Para las existencias {2, 4, 0}, dibuja las posiciones y marca qué condición detendría la búsqueda. Después cambia el cero a la última posición y repite la comprobación.

## Dossier

Implementa un método por ejercicio. Las diez pruebas suministradas se corresponden con los ejercicios en orden.

### 01 · Sumar existencias

Método: `int sumar(int[] datos)`. Suma mediante for-each. Devuelve 0 para un array vacío.

### 02 · Contar agotados

Método: `int contarAgotados(int[] datos)`. Cuenta todas las posiciones con cero.

### 03 · Primer agotado

Método: `int primerAgotado(int[] datos)`. Devuelve el índice del primer cero, o -1 si no aparece.

### 04 · Mayor stock

Método: `int indiceMayorStock(int[] datos)`. Devuelve el primer índice del mayor valor. Para un array vacío devuelve -1.

### 05 · Stock medio

Método: `double media(int[] datos)`. Calcula la media con división decimal. Devuelve 0.0 si no hay datos.

### 06 · Reposición

Método: `int[] indicesBajoMinimo(int[] datos, int minimo)`. Devuelve en orden los índices cuyo valor sea estrictamente menor que el mínimo. Cuenta primero para reservar el tamaño exacto del array de salida.

### 07 · Comparar recuentos

Método: `int contarCambios(int[] antes, int[] despues)`. Cuenta las posiciones que cambian. Lanza IllegalArgumentException cuando las longitudes difieran.

### 08 · Depurar un límite

Método: `int sumarConIndices(int[] datos)`. Implementa sumarConIndices con un bucle por índice. Introduce temporalmente el límite i <= datos.length y reproduce el error con {5, 0, 3}. Registra el índice 3, corrige la condición y prueba el array vacío y el unitario.

### 09 · Retirar existencias

Método: `boolean retirar(int[] datos, int indice, int cantidad)`. Si el índice es válido, la cantidad es positiva y hay stock suficiente, descuenta y devuelve true. En otro caso devuelve false y conserva el array.

### 10 · Simular una jornada

Método: `int simularJornada(int[] datos, int[] indices, int[] cantidades)`. Aplica las retiradas en orden utilizando retirar y devuelve cuántas se aceptaron. Si los arrays de operaciones no tienen igual longitud, lanza IllegalArgumentException antes de modificar el stock.

**Entrega:** código, salida de Maven y traza del índice en el ejercicio 08.

## Cómo documentar tu código con Javadoc

Añade un bloque Javadoc encima de cada método y constructor que completes, incluido `main` si existe.
Describe qué hace, qué espera recibir y qué resultado promete. Indica si modifica un objeto,
un array o un fichero. Revisa también que la descripción de cada clase explique su responsabilidad.

- Usa `@param` con el nombre de cada parámetro y explica qué representa y qué valores admite.
- Usa `@return` si el método devuelve un valor. En un método `void` o en un constructor puedes omitirlo.
- Usa `@throws` para explicar qué condición provoca cada excepción que forme parte del contrato.
- Si `main` no utiliza los argumentos de la terminal, indícalo al documentar `args`.

**Modelo para un método ajeno a la tarea**

```java
/**
 * Devuelve el número de páginas de un cuaderno.
 * @param hojas número de hojas del cuaderno, mayor o igual que cero
 * @return número de páginas del cuaderno
 * @throws IllegalArgumentException si el número de hojas es negativo
 */
```

Genera la documentación con `mvn javadoc:javadoc`. Abre `target/site/apidocs/index.html` y comprueba
que se entiende el contrato sin leer el cuerpo del método.
