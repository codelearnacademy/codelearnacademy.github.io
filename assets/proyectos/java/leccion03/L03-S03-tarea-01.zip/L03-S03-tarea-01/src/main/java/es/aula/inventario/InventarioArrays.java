package es.aula.inventario;

public final class InventarioArrays {
    private InventarioArrays() {}

    public static int sumar(int[] datos) {
        throw new UnsupportedOperationException("Ejercicio 01 pendiente");
    }

    public static int contarAgotados(int[] datos) {
        throw new UnsupportedOperationException("Ejercicio 02 pendiente");
    }

    public static int primerAgotado(int[] datos) {
        throw new UnsupportedOperationException("Ejercicio 03 pendiente");
    }

    public static int indiceMayorStock(int[] datos) {
        throw new UnsupportedOperationException("Ejercicio 04 pendiente");
    }

    public static double media(int[] datos) {
        throw new UnsupportedOperationException("Ejercicio 05 pendiente");
    }

    public static int[] indicesBajoMinimo(int[] datos, int minimo) {
        throw new UnsupportedOperationException("Ejercicio 06 pendiente");
    }

    public static int contarCambios(int[] antes, int[] despues) {
        throw new UnsupportedOperationException("Ejercicio 07 pendiente");
    }

    public static int sumarConIndices(int[] datos) {
        throw new UnsupportedOperationException("Ejercicio 08 pendiente");
    }

    public static boolean retirar(int[] datos, int indice, int cantidad) {
        throw new UnsupportedOperationException("Ejercicio 09 pendiente");
    }

    public static int simularJornada(int[] datos, int[] indices, int[] cantidades) {
        throw new UnsupportedOperationException("Ejercicio 10 pendiente");
    }
}
