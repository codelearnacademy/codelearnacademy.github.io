package es.aula.inventario;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static es.aula.inventario.InventarioArrays.*;

class InventarioArraysTest {
    @Test
    void ejercicio01() {
        assertEquals(8, sumar(new int[]{5, 0, 3}));
        assertEquals(0, sumar(new int[]{}));
    }

    @Test
    void ejercicio02() {
        assertEquals(2, contarAgotados(new int[]{5, 0, 3, 0}));
        assertEquals(0, contarAgotados(new int[]{}));
    }

    @Test
    void ejercicio03() {
        assertEquals(1, primerAgotado(new int[]{5, 0, 3, 0}));
        assertEquals(-1, primerAgotado(new int[]{5, 3}));
        assertEquals(-1, primerAgotado(new int[]{}));
    }

    @Test
    void ejercicio04() {
        assertEquals(1, indiceMayorStock(new int[]{3, 8, 8, 2}));
        assertEquals(-1, indiceMayorStock(new int[]{}));
    }

    @Test
    void ejercicio05() {
        assertEquals(2.25, media(new int[]{5, 0, 3, 1}), 0.0001);
        assertEquals(0.0, media(new int[]{}), 0.0001);
    }

    @Test
    void ejercicio06() {
        assertArrayEquals(new int[]{1, 3}, indicesBajoMinimo(new int[]{5, 0, 3, 1}, 3));
        assertArrayEquals(new int[]{}, indicesBajoMinimo(new int[]{3, 5}, 3));
    }

    @Test
    void ejercicio07() {
        assertEquals(2, contarCambios(new int[]{5, 0, 3}, new int[]{4, 0, 5}));
        assertThrows(IllegalArgumentException.class, () -> contarCambios(new int[]{1}, new int[]{}));
    }

    @Test
    void ejercicio08() {
        assertEquals(8, sumarConIndices(new int[]{5, 0, 3}));
        assertEquals(0, sumarConIndices(new int[]{}));
        assertEquals(7, sumarConIndices(new int[]{7}));
    }

    @Test
    void ejercicio09() {
        int[] datos = {5, 0, 3};
        assertFalse(retirar(datos, 0, 6));
        assertFalse(retirar(datos, -1, 1));
        assertFalse(retirar(datos, 0, 0));
        assertArrayEquals(new int[]{5, 0, 3}, datos);
        assertTrue(retirar(datos, 0, 5));
        assertArrayEquals(new int[]{0, 0, 3}, datos);
    }

    @Test
    void ejercicio10() {
        int[] datos = {5, 0, 3};
        assertThrows(IllegalArgumentException.class, () -> simularJornada(datos, new int[]{0, 1}, new int[]{1}));
        assertArrayEquals(new int[]{5, 0, 3}, datos);
        assertEquals(2, simularJornada(datos, new int[]{0, 1, 2}, new int[]{1, 1, 3}));
        assertArrayEquals(new int[]{4, 0, 0}, datos);
    }

}
