/** Punto de partida del dossier «Validar entradas y capturar excepciones». */
public class Main {
    public static void main(String[] args) throws Exception {
        throw new UnsupportedOperationException("Implementa los requisitos del README");
    }
}
