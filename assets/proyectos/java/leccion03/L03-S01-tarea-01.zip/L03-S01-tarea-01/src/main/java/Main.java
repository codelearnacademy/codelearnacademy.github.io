/** Punto de partida del dossier «Selección con if y switch». */
public class Main {
    public static void main(String[] args) throws Exception {
        throw new UnsupportedOperationException("Implementa los requisitos del README");
    }
}
