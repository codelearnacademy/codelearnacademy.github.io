package aula;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Editor extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("Inventario de aula");
        stage.setScene(new Scene(FXMLLoader.load(Editor.class.getResource("/editor.fxml"))));
        stage.show();
    }

    public static void main(String[] args) { launch(args); }
}
