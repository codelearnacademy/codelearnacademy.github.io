package aula;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class Controlador {
    private final Path archivo = Path.of("existencias.txt");
    @FXML private TextField cantidad;
    @FXML private Label estado;

    @FXML
    private void initialize() {
        try {
            cantidad.setText(Files.readString(archivo).strip());
        } catch (IOException ex) {
            estado.setText("No se pudo leer existencias.txt");
        }
    }

    @FXML
    private void guardar() {
        try {
            int valor = Integer.parseInt(cantidad.getText().strip());
            if (valor < 0) throw new NumberFormatException();
            Files.writeString(archivo, valor + System.lineSeparator());
            estado.setText("Guardado: " + valor);
        } catch (NumberFormatException ex) {
            estado.setText("Introduce un entero no negativo.");
        } catch (IOException ex) {
            estado.setText("No se pudo guardar el fichero.");
        }
    }
}
