# Editor de existencias

Abre el proyecto Maven. Ejecuta `mvn javafx:run` desde esta carpeta en un escritorio gráfico.
Guarda 4, cierra la ventana y reabre. Comprueba que sigue mostrando 4.
Introduce -1 y luego texto. En ambos casos el fichero debe seguir conteniendo 4.
El proyecto inicial usa un fichero de una sola cantidad para MAT-01. Amplíalo a varias filas como pide la práctica.
