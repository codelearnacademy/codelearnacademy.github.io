# L02-S05-tarea-01 · Entrada y salida con Scanner

![Resumen del encargo y comprobación de Entrada y salida con Scanner](infografia.webp)

## Qué debes hacer

Introduce 5 y separa la lectura del formato de salida.

Implementa el comportamiento de esta ficha en `src/main/java` y resuelve los diez ejercicios de abajo. Usa **Java 21** y abre el `pom.xml` desde tu IDE. El código contiene firmas pendientes que lanzan `UnsupportedOperationException` hasta que las completes. Conserva los nombres que usan las pruebas.

## Ejemplo orientativo

Si el usuario escribe «Ada Lovelace» en una línea y «7» en la siguiente, diseña una salida que conserve el nombre completo. Anota cuándo debe terminar cada lectura.

## Primera comprobación automática

La prueba proporciona la entrada `5` seguida de un salto de línea. Tu programa debe leerla de la entrada estándar.

Resultado de referencia:

```text
5 unidades
```

Ejecuta `mvn test` desde la carpeta del proyecto. La prueba suministrada comprueba el comportamiento descrito en esta sección y debe fallar mientras esté pendiente. Si el ejercicio consiste en compilar, lanzar o depurar, registra también el comando, la salida y la causa que observaste.

## Dossier de diez ejercicios

Desarrolla cada ejercicio en un método o clase propia, o amplía el programa cuando el enunciado lo requiera. Para cada uno, anota una entrada concreta y el resultado esperado antes de ejecutarlo. Añade una prueba JUnit para la lógica nueva. En los últimos tres, incluye también un caso límite o de error.

1. Lee un entero.
2. Lee un nombre completo.
3. Imprime una ficha con printf.
4. Lee nombre y cantidad en líneas distintas.
5. Lee cantidad seguida de nombre.
6. Rechaza texto no numérico.
7. Lee tres cantidades y calcula su suma.
8. Corrige el salto pendiente de nextInt.
9. Gestiona fin de entrada antes de leer.
10. Construye un registro de material con salida alineada.

## Entrega

- Ejecuta `mvn test` y `mvn javadoc:javadoc`. Entrega el código, las pruebas y una tabla con entrada, resultado esperado y resultado obtenido.

## Cómo documentar tu código con Javadoc

Añade un bloque Javadoc encima de cada método y constructor que completes, incluido `main` si existe.
Describe qué hace, qué espera recibir y qué resultado promete. Indica si modifica un objeto,
un array o un fichero. Revisa también que la descripción de cada clase explique su responsabilidad.

- Usa `@param` con el nombre de cada parámetro y explica qué representa y qué valores admite.
- Usa `@return` si el método devuelve un valor. En un método `void` o en un constructor puedes omitirlo.
- Usa `@throws` para explicar qué condición provoca cada excepción que forme parte del contrato.
- Si `main` no utiliza los argumentos de la terminal, indícalo al documentar `args`.

**Modelo para un método ajeno a la tarea**

```java
/**
 * Devuelve el número de páginas de un cuaderno.
 * @param hojas número de hojas del cuaderno, mayor o igual que cero
 * @return número de páginas del cuaderno
 * @throws IllegalArgumentException si el número de hojas es negativo
 */
```

Genera la documentación con `mvn javadoc:javadoc`. Abre `target/site/apidocs/index.html` y comprueba
que se entiende el contrato sin leer el cuerpo del método.
