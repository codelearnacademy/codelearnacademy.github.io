# L02-S03-tarea-01 · Operadores y expresiones

![Resumen del encargo y comprobación de Operadores y expresiones](infografia.webp)

## Qué debes hacer

Calcula el coste de un pedido de 5 unidades a 250 céntimos por unidad, con un cargo fijo de 100 céntimos por pedido. Muestra el total en céntimos. Después, prueba a cambiar los paréntesis y explica qué cálculo representa cada expresión.

Implementa el comportamiento de esta ficha en `src/main/java` y resuelve los diez ejercicios de abajo. Usa **Java 21** y abre el `pom.xml` desde tu IDE. El código contiene firmas pendientes que lanzan `UnsupportedOperationException` hasta que las completes. Conserva los nombres que usan las pruebas.

## Ejemplo orientativo

Para presupuestar un envío, compara `2 * 4 + 3` y `2 * (4 + 3)`. El cargo fijo es 3 por envío: el primer cálculo da 11 y el segundo da 14 porque aplica el cargo a cada unidad. Haz una tabla similar con los datos de inventario del dossier.

## Primera comprobación automática


Resultado de referencia:

```text
1350
```

Ejecuta `mvn test` desde la carpeta del proyecto. La prueba suministrada comprueba el comportamiento descrito en esta sección y debe fallar mientras esté pendiente. Si el ejercicio consiste en compilar, lanzar o depurar, registra también el comando, la salida y la causa que observaste.

## Dossier de diez ejercicios

Desarrolla cada ejercicio en un método o clase propia, o amplía el programa cuando el enunciado lo requiera. Para cada uno, anota una entrada concreta y el resultado esperado antes de ejecutarlo. Añade una prueba JUnit para la lógica nueva. En los últimos tres, incluye también un caso límite o de error.

1. Suma entradas y resta salidas.
2. Calcula cajas completas.
3. Calcula unidades sobrantes.
4. Aplica un cargo fijo al importe.
5. Compara dos cantidades con un boolean.
6. Combina dos condiciones de disponibilidad.
7. Compara resultados con y sin paréntesis.
8. Explica y corrige una división por cero.
9. Corrige una concatenación que aparenta sumar.
10. Descompón un pedido en cajas y calcula su coste final.

## Entrega

- Ejecuta `mvn test` y `mvn javadoc:javadoc`. Entrega el código, las pruebas y una tabla con entrada, resultado esperado y resultado obtenido.

## Cómo documentar tu código con Javadoc

Añade un bloque Javadoc encima de cada método y constructor que completes, incluido `main` si existe.
Describe qué hace, qué espera recibir y qué resultado promete. Indica si modifica un objeto,
un array o un fichero. Revisa también que la descripción de cada clase explique su responsabilidad.

- Usa `@param` con el nombre de cada parámetro y explica qué representa y qué valores admite.
- Usa `@return` si el método devuelve un valor. En un método `void` o en un constructor puedes omitirlo.
- Usa `@throws` para explicar qué condición provoca cada excepción que forme parte del contrato.
- Si `main` no utiliza los argumentos de la terminal, indícalo al documentar `args`.

**Modelo para un método ajeno a la tarea**

```java
/**
 * Devuelve el número de páginas de un cuaderno.
 * @param hojas número de hojas del cuaderno, mayor o igual que cero
 * @return número de páginas del cuaderno
 * @throws IllegalArgumentException si el número de hojas es negativo
 */
```

Genera la documentación con `mvn javadoc:javadoc`. Abre `target/site/apidocs/index.html` y comprueba
que se entiende el contrato sin leer el cuerpo del método.
