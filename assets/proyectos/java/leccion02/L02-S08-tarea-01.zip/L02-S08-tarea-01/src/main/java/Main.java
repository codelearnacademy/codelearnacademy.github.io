/** Punto de partida del dossier «Métodos, parámetros y retorno». */
public class Main {
    public static void main(String[] args) throws Exception {
        throw new UnsupportedOperationException("Implementa los requisitos del README");
    }
}
