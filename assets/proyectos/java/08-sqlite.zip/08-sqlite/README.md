# Inventario relacional

Usa un archivo nuevo, por ejemplo aula.db. Cada comando se ejecuta en un proceso distinto.

```bash
mvn compile exec:java -Dexec.args="aula.db crear 1 5"
mvn exec:java -Dexec.args="aula.db fallo 1"
mvn exec:java -Dexec.args="aula.db listar"
mvn exec:java -Dexec.args="aula.db salida 1"
mvn exec:java -Dexec.args="aula.db listar"
```

El comando fallo devuelve un error deliberado. La primera lectura debe mostrar 5 unidades
y 0 salidas. La segunda debe mostrar 4 unidades y 1 salida. Repite la lectura tras reiniciar
para comprobar la persistencia. Con el ID 2 puedes ensayar crear, actualizar, listar y borrar.
Intenta crear una cantidad negativa y borrar el ID 1 después de registrar una salida para verificar las restricciones.
