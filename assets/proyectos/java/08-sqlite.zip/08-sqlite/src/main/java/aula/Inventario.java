package aula;

import java.sql.*;

public class Inventario {
    public static void main(String[] args) throws SQLException {
        if (args.length < 2) {
            System.out.println("Uso: archivo.db listar|crear|actualizar|borrar|salida|fallo [id] [unidades]");
            return;
        }
        try (Connection db = DriverManager.getConnection("jdbc:sqlite:" + args[0]);
             Statement sql = db.createStatement()) {
            sql.execute("PRAGMA foreign_keys = ON");
            sql.execute("CREATE TABLE IF NOT EXISTS material(id INTEGER PRIMARY KEY, cantidad INTEGER NOT NULL CHECK(cantidad >= 0))");
            sql.execute("CREATE TABLE IF NOT EXISTS movimiento(id INTEGER PRIMARY KEY, material_id INTEGER NOT NULL REFERENCES material(id))");
            switch (args[1]) {
                case "crear" -> modificar(db, "INSERT INTO material(id,cantidad) VALUES (?,?)", numero(args,2), numero(args,3));
                case "actualizar" -> modificar(db, "UPDATE material SET cantidad=? WHERE id=?", numero(args,3), numero(args,2));
                case "borrar" -> modificar(db, "DELETE FROM material WHERE id=?", numero(args,2));
                case "salida", "fallo" -> registrarSalida(db, numero(args,2), args[1].equals("fallo"));
                case "listar" -> {
                    try (ResultSet r = sql.executeQuery("SELECT m.id,m.cantidad,(SELECT COUNT(*) FROM movimiento s WHERE s.material_id=m.id) FROM material m ORDER BY m.id")) {
                        while (r.next()) {
                            System.out.printf("ID %d | unidades %d | salidas %d%n", r.getInt(1), r.getInt(2), r.getInt(3));
                        }
                    }
                }
                default -> throw new IllegalArgumentException("Comando desconocido");
            }
        }
    }

    private static int numero(String[] args, int indice) {
        if (indice >= args.length) throw new IllegalArgumentException("Falta un argumento numérico");
        return Integer.parseInt(args[indice]);
    }

    private static int modificar(Connection db, String sql, int... valores) throws SQLException {
        try (PreparedStatement consulta = db.prepareStatement(sql)) {
            for (int i = 0; i < valores.length; i++) consulta.setInt(i + 1, valores[i]);
            return consulta.executeUpdate();
        }
    }

    private static void registrarSalida(Connection db, int id, boolean forzarFallo) throws SQLException {
        db.setAutoCommit(false);
        try {
            modificar(db, "INSERT INTO movimiento(material_id) VALUES (?)", id);
            String sql = "UPDATE material SET cantidad=cantidad-1 WHERE id=? AND cantidad>0";
            if (forzarFallo) sql += " AND 1=0";
            if (modificar(db, sql, id) != 1) throw new SQLException("No se descontó la unidad");
            db.commit();
        } catch (SQLException original) {
            try {
                db.rollback();
            } catch (SQLException errorDeRollback) {
                original.addSuppressed(errorDeRollback);
            }
            throw original;
        }
    }
}
