/** Punto de partida del dossier «Buscar por identidad y consulta». */
public class Main {
    public static void main(String[] args) throws Exception {
        throw new UnsupportedOperationException("Implementa los requisitos del README");
    }
}
