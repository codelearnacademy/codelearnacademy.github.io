/** Punto de partida del dossier «Configurar el gestor y crear la base». */
public class Main {
    public static void main(String[] args) throws Exception {
        throw new UnsupportedOperationException("Implementa los requisitos del README");
    }
}
