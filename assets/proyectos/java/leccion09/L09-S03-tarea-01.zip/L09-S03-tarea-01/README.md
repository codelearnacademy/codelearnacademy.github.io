# L09-S03-tarea-01 · Guardar objetos relacionados

![Resumen del encargo y comprobación de Guardar objetos relacionados](infografia.webp)

## Qué debes hacer

Crea y recupera un préstamo con una línea que referencia un material. Usa un fichero nuevo.

Implementa el comportamiento de esta ficha en `src/main/java` y resuelve los diez ejercicios de abajo. Usa **Java 21** y abre el `pom.xml` desde tu IDE. El código contiene firmas pendientes que lanzan `UnsupportedOperationException` hasta que las completes. Conserva los nombres que usan las pruebas.

## Ejemplo orientativo

Dos reservas apuntan a la misma sala. Comprueba si al reabrir se conserva la referencia compartida y qué debería pasar con la sala si borras una reserva.

## Primera comprobación automática

Implementa las clases persistentes suministradas y `aula.Prestamos.main(String[] args)`. El primer argumento es el fichero .odb y el segundo el comando. La prueba invoca `crear` en una base temporal y recupera P1 tras reabrirla. Debe existir una línea de dos unidades de MAT-01, visible en `Prestamo.detalle()`. Amplía los comandos a medida que resuelvas el dossier.

Resultado de referencia:

```text
Préstamo P1 recuperado después de reabrir la base, con una línea que contiene MAT-01 x 2.
```

Ejecuta `mvn test` desde la carpeta del proyecto. La prueba suministrada comprueba el comportamiento descrito en esta sección y debe fallar mientras esté pendiente. Si el ejercicio consiste en compilar, lanzar o depurar, registra también el comando, la salida y la causa que observaste.

## Dossier de diez ejercicios

Desarrolla cada ejercicio en un método o clase propia, o amplía el programa cuando el enunciado lo requiera. Para cada uno, anota una entrada concreta y el resultado esperado antes de ejecutarlo. Añade una prueba JUnit para la lógica nueva. En los últimos tres, incluye también un caso límite o de error.

1. Guarda un material.
2. Añade una línea embebida.
3. Persiste un préstamo.
4. Añade otra línea.
5. Reutiliza un mismo material.
6. Cuenta unidades de las líneas.
7. Recupera los detalles al reabrir.
8. Rechaza cantidad no positiva.
9. Verifica material compartido.
10. Guarda y recupera dos préstamos relacionados.

## Entrega

- Ejecuta `mvn test` y `mvn javadoc:javadoc`. Entrega el código, las pruebas y una tabla con entrada, resultado esperado y resultado obtenido.

## Cómo documentar tu código con Javadoc

Añade un bloque Javadoc encima de cada método y constructor que completes, incluido `main` si existe.
Describe qué hace, qué espera recibir y qué resultado promete. Indica si modifica un objeto,
un array o un fichero. Revisa también que la descripción de cada clase explique su responsabilidad.

- Usa `@param` con el nombre de cada parámetro y explica qué representa y qué valores admite.
- Usa `@return` si el método devuelve un valor. En un método `void` o en un constructor puedes omitirlo.
- Usa `@throws` para explicar qué condición provoca cada excepción que forme parte del contrato.
- Si `main` no utiliza los argumentos de la terminal, indícalo al documentar `args`.

**Modelo para un método ajeno a la tarea**

```java
/**
 * Devuelve el número de páginas de un cuaderno.
 * @param hojas número de hojas del cuaderno, mayor o igual que cero
 * @return número de páginas del cuaderno
 * @throws IllegalArgumentException si el número de hojas es negativo
 */
```

Genera la documentación con `mvn javadoc:javadoc`. Abre `target/site/apidocs/index.html` y comprueba
que se entiende el contrato sin leer el cuerpo del método.
