/** Punto de partida del dossier «Qué almacena una base orientada a objetos». */
public class Main {
    public static void main(String[] args) throws Exception {
        throw new UnsupportedOperationException("Implementa los requisitos del README");
    }
}
