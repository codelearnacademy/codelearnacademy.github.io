package aula;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Prestamo {
    @Id private String id;
    private String estado;
    @ElementCollection private List<Linea> lineas = new ArrayList<>();

    protected Prestamo() {}
    public Prestamo(String id, Material material) { throw new UnsupportedOperationException("Implementa el contrato del README"); }
    public void cerrar() { throw new UnsupportedOperationException("Implementa el contrato del README"); }
    public String detalle() { throw new UnsupportedOperationException("Implementa el contrato del README"); }
}
