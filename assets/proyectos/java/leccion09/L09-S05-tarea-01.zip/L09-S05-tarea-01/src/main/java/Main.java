/** Punto de partida del dossier «Actualizar, revertir y borrar». */
public class Main {
    public static void main(String[] args) throws Exception {
        throw new UnsupportedOperationException("Implementa los requisitos del README");
    }
}
