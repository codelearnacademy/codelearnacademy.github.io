package aula;

import jakarta.persistence.*;

@Entity
public class Material {
    @Id private String codigo;
    protected Material() {}
    public Material(String codigo) { throw new UnsupportedOperationException("Implementa el contrato del README"); }
    public String codigo() { throw new UnsupportedOperationException("Implementa el contrato del README"); }
}
