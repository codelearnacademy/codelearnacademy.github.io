package aula;

import jakarta.persistence.EntityManager;

/** Operaciones de consola sobre los préstamos. */
public class Prestamos {
    public static void main(String[] args) {
        throw new UnsupportedOperationException("Implementa la apertura, el comando y el cierre");
    }

    private static void operar(EntityManager gestor, String comando) {
        throw new UnsupportedOperationException("Implementa los comandos del README");
    }
}
