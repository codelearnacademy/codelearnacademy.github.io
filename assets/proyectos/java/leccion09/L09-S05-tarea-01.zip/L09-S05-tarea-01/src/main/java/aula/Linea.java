package aula;

import jakarta.persistence.*;

@Embeddable
public class Linea {
    @ManyToOne(optional = false) private Material material;
    private int cantidad;

    protected Linea() {}
    public Linea(Material material, int cantidad) { throw new UnsupportedOperationException("Implementa el contrato del README"); }
    public String detalle() { throw new UnsupportedOperationException("Implementa el contrato del README"); }
}
