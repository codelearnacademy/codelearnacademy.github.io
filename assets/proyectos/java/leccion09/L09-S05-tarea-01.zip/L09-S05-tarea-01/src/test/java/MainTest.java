import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

class MainTest {
    @Test
    void guardaYRecuperaUnPrestamo(@org.junit.jupiter.api.io.TempDir java.nio.file.Path carpeta) {
        String base = carpeta.resolve("prueba.odb").toString();
        aula.Prestamos.main(new String[]{base, "crear"});
        var fabrica = jakarta.persistence.Persistence.createEntityManagerFactory(base);
        try {
            var gestor = fabrica.createEntityManager();
            try {
                var prestamo = gestor.find(aula.Prestamo.class, "P1");
                assertNotNull(prestamo);
                assertTrue(prestamo.detalle().contains("MAT-01 x 2"));
            } finally { gestor.close(); }
        } finally { fabrica.close(); }
    }

}
