import aula.inventario.Material;

public class Main {
    public static void main(String[] args) {
        int restantes = new Material(5).retirar(1).unidades();
        if (restantes != 4) throw new AssertionError(restantes);
        System.out.println("Unidades restantes: " + restantes);
    }
}
