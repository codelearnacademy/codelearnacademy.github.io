package aula.inventario;

/** Material con existencias no negativas. */
public final class Material {
    private final int unidades;

    public Material(int unidades) {
        if (unidades < 0) throw new IllegalArgumentException("Existencias negativas");
        this.unidades = unidades;
    }

    public Material retirar(int cantidad) {
        if (cantidad <= 0 || cantidad > unidades) {
            throw new IllegalArgumentException("Retirada inválida");
        }
        return new Material(unidades - cantidad);
    }

    public int unidades() { return unidades; }
}
