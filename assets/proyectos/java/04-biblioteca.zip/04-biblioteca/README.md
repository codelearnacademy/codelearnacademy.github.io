# Biblioteca y cliente

Desde la carpeta del proyecto, con el JDK 21:

```bash
javac -d out biblioteca/aula/inventario/Material.java
jar --create --file inventario.jar -C out .
java --class-path inventario.jar cliente/Main.java
```

En el IDE abre las carpetas `biblioteca` y `cliente` como proyectos separados.
Añade `inventario.jar` a las bibliotecas del cliente y ejecuta `Main`.
Se esperan 4 unidades. Prueba una retirada superior al stock y amplía la biblioteca con `Movimiento`.
