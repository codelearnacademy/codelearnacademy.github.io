package aula;

public class Main {
    public static void main(String[] args) {
        System.out.println("Ada · Java " + Runtime.version().feature());
        System.out.println("Estoy listo para aprender");
    }
}
