# Primer proyecto en el IDE

1. Descomprime el ZIP y abre su carpeta como proyecto Maven en el IDE.
2. En la configuración del proyecto y de ejecución, selecciona un JDK 21.
3. Abre `aula.Main` y ejecuta su método `main`. Guarda la salida y la configuración del JDK.
4. Cambia temporalmente el nombre de la clase pública, compila, explica el error y restaura el nombre.

Desde terminal ejecuta `mvn compile exec:java`.
