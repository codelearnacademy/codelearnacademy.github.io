/** Punto de partida del dossier «Leer y escribir con Path y Files». */
public class Main {
    public static void main(String[] args) throws Exception {
        throw new UnsupportedOperationException("Implementa los requisitos del README");
    }
}
