# L05-S05-tarea-01 · Crear una vista JavaFX

![Resumen del encargo y comprobación de Crear una vista JavaFX](infografia.webp)

## Qué debes hacer

En el proyecto JavaFX, conecta la vista FXML con un controlador. Este ejemplo construye una vista mínima por código.

Implementa el comportamiento de esta ficha en `src/main/java` y resuelve los diez ejercicios de abajo. Usa **Java 21** y abre el `pom.xml` desde tu IDE. El código contiene firmas pendientes que lanzan `UnsupportedOperationException` hasta que las completes. Conserva los nombres que usan las pruebas.

## Ejemplo orientativo

Dibuja un formulario de devolución con un campo de código y una etiqueta. Anota qué valor inicial debe verse antes de pulsar ningún botón.

## Primera comprobación automática

Implementa `Main.stockInicial()` para devolver el texto que se muestra al cargar el formulario. Conecta ese método con la vista. JUnit comprueba el dato inicial sin abrir una ventana. Para verificar la vista, ejecuta `mvn javafx:run`.

Resultado de referencia:

```text
5
```

Ejecuta `mvn test` desde la carpeta del proyecto. La prueba suministrada comprueba el comportamiento descrito en esta sección y debe fallar mientras esté pendiente. Si el ejercicio consiste en compilar, lanzar o depurar, registra también el comando, la salida y la causa que observaste.

## Dossier de diez ejercicios

Desarrolla cada ejercicio en un método o clase propia, o amplía el programa cuando el enunciado lo requiera. Para cada uno, anota una entrada concreta y el resultado esperado antes de ejecutarlo. Añade una prueba JUnit para la lógica nueva. En los últimos tres, incluye también un caso límite o de error.

1. Crea un campo.
2. Añade una etiqueta.
3. Muestra el stock inicial.
4. Alinea los controles.
5. Añade un botón.
6. Carga datos iniciales.
7. Presenta dos materiales.
8. Detecta un fx:id incorrecto.
9. Comprueba un recurso FXML ausente.
10. Muestra un formulario de inventario utilizable.

## Entrega

- Ejecuta `mvn test` y `mvn javadoc:javadoc`. Entrega el código, las pruebas y una tabla con entrada, resultado esperado y resultado obtenido.

## Cómo documentar tu código con Javadoc

Añade un bloque Javadoc encima de cada método y constructor que completes, incluido `main` si existe.
Describe qué hace, qué espera recibir y qué resultado promete. Indica si modifica un objeto,
un array o un fichero. Revisa también que la descripción de cada clase explique su responsabilidad.

- Usa `@param` con el nombre de cada parámetro y explica qué representa y qué valores admite.
- Usa `@return` si el método devuelve un valor. En un método `void` o en un constructor puedes omitirlo.
- Usa `@throws` para explicar qué condición provoca cada excepción que forme parte del contrato.
- Si `main` no utiliza los argumentos de la terminal, indícalo al documentar `args`.

**Modelo para un método ajeno a la tarea**

```java
/**
 * Devuelve el número de páginas de un cuaderno.
 * @param hojas número de hojas del cuaderno, mayor o igual que cero
 * @return número de páginas del cuaderno
 * @throws IllegalArgumentException si el número de hojas es negativo
 */
```

Genera la documentación con `mvn javadoc:javadoc`. Abre `target/site/apidocs/index.html` y comprueba
que se entiende el contrato sin leer el cuerpo del método.
