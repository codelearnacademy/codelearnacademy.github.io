/** Punto de partida del dossier «Crear una vista JavaFX». */
public class Main extends javafx.application.Application {
    @Override
    public void start(javafx.stage.Stage stage) {
        throw new UnsupportedOperationException("Construye la vista según el README");
    }

    public static void main(String[] args) {
        launch(args);
    }
    
    static String stockInicial() {
        throw new UnsupportedOperationException("Implementa la cantidad inicial");
    }
}
