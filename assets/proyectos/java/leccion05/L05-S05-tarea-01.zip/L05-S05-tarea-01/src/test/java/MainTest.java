import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

class MainTest {
    @Test void muestraLaCantidadInicial() { assertEquals("5", Main.stockInicial()); }

}
