/** Punto de partida del dossier «Controlar eventos y validar». */
public class Main extends javafx.application.Application {
    @Override
    public void start(javafx.stage.Stage stage) {
        throw new UnsupportedOperationException("Construye la vista según el README");
    }

    public static void main(String[] args) {
        launch(args);
    }
    
    static String validar(String valor) {
        throw new UnsupportedOperationException("Implementa la validación");
    }
}
