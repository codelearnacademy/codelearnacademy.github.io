import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

class MainTest {
    @Test void validaCantidad() {
        assertEquals("Cantidad negativa", Main.validar("-1"));
        assertEquals("Cantidad válida", Main.validar("5"));
        assertEquals("Introduce un entero", Main.validar("cinco"));
    }

}
