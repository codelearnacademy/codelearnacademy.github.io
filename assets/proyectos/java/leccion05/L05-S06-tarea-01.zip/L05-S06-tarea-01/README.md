# L05-S06-tarea-01 · Controlar eventos y validar

![Resumen del encargo y comprobación de Controlar eventos y validar](infografia.webp)

## Qué debes hacer

Un controlador se ejecuta al pulsar un botón. Comprueba el valor antes de guardar.

Implementa el comportamiento de esta ficha en `src/main/java` y resuelve los diez ejercicios de abajo. Usa **Java 21** y abre el `pom.xml` desde tu IDE. El código contiene firmas pendientes que lanzan `UnsupportedOperationException` hasta que las completes. Conserva los nombres que usan las pruebas.

## Ejemplo orientativo

Para un campo de plazas, prueba con «3» y «-2». Describe qué mensaje debe cambiar al pulsar Guardar y en qué caso se debe conservar el dato anterior.

## Primera comprobación automática

Implementa `Main.validar(String)` con los tres resultados indicados y llama a ese método desde el evento del botón. JUnit comprueba la validación. Abre la interfaz con `mvn javafx:run` para comprobar el evento.

Resultado de referencia:

```text
-1 → Cantidad negativa
5 → Cantidad válida
cinco → Introduce un entero
```

Ejecuta `mvn test` desde la carpeta del proyecto. La prueba suministrada comprueba el comportamiento descrito en esta sección y debe fallar mientras esté pendiente. Si el ejercicio consiste en compilar, lanzar o depurar, registra también el comando, la salida y la causa que observaste.

## Dossier de diez ejercicios

Desarrolla cada ejercicio en un método o clase propia, o amplía el programa cuando el enunciado lo requiera. Para cada uno, anota una entrada concreta y el resultado esperado antes de ejecutarlo. Añade una prueba JUnit para la lógica nueva. En los últimos tres, incluye también un caso límite o de error.

1. Vincula Guardar.
2. Lee el valor del campo.
3. Actualiza la etiqueta.
4. Valida un entero.
5. Rechaza una cantidad negativa.
6. Guarda el dato válido.
7. Recupera el dato al reabrir.
8. Comprueba texto no numérico.
9. Conserva el fichero ante rechazo.
10. Completa el flujo de edición y confirmación.

## Entrega

- Ejecuta `mvn test` y `mvn javadoc:javadoc`. Entrega el código, las pruebas y una tabla con entrada, resultado esperado y resultado obtenido.

## Cómo documentar tu código con Javadoc

Añade un bloque Javadoc encima de cada método y constructor que completes, incluido `main` si existe.
Describe qué hace, qué espera recibir y qué resultado promete. Indica si modifica un objeto,
un array o un fichero. Revisa también que la descripción de cada clase explique su responsabilidad.

- Usa `@param` con el nombre de cada parámetro y explica qué representa y qué valores admite.
- Usa `@return` si el método devuelve un valor. En un método `void` o en un constructor puedes omitirlo.
- Usa `@throws` para explicar qué condición provoca cada excepción que forme parte del contrato.
- Si `main` no utiliza los argumentos de la terminal, indícalo al documentar `args`.

**Modelo para un método ajeno a la tarea**

```java
/**
 * Devuelve el número de páginas de un cuaderno.
 * @param hojas número de hojas del cuaderno, mayor o igual que cero
 * @return número de páginas del cuaderno
 * @throws IllegalArgumentException si el número de hojas es negativo
 */
```

Genera la documentación con `mvn javadoc:javadoc`. Abre `target/site/apidocs/index.html` y comprueba
que se entiende el contrato sin leer el cuerpo del método.
