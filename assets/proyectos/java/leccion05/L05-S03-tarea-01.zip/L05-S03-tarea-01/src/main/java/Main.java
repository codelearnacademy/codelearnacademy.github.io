/** Punto de partida del dossier «Procesar un fichero línea a línea». */
public class Main {
    public static void main(String[] args) throws Exception {
        throw new UnsupportedOperationException("Implementa los requisitos del README");
    }
}
