# Importación de JSON y XML

Ejecuta `mvn compile exec:java` desde esta carpeta. Verifica que lee dos elementos XML,
escribe salida.json y obtiene 7 al releerla. Duplica un código en entrada.json y comprueba el rechazo.
Amplía el punto de partida para modificar y guardar el XML y completar los requisitos de genéricos y matrices de la práctica.
