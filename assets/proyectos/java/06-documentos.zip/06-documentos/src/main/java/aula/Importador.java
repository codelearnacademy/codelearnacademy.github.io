package aula;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.List;
import java.util.regex.Pattern;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;

public class Importador {
    public record Material(String codigo, String categoria, int cantidad) {}

    public static void main(String[] args) throws Exception {
        var mapper = new ObjectMapper();
        List<Material> materiales = List.of(mapper.readValue(Path.of("entrada.json").toFile(), Material[].class));
        var patron = Pattern.compile("MAT-[0-9]{2}");
        var codigos = new HashSet<String>();
        var it = materiales.iterator();
        while (it.hasNext()) {
            Material material = it.next();
            if (material.codigo() == null || !patron.matcher(material.codigo()).matches()
                    || !codigos.add(material.codigo()) || material.cantidad() < 0) {
                throw new IllegalArgumentException("Registro inválido: " + material);
            }
        }
        var xml = DocumentBuilderFactory.newInstance();
        xml.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        xml.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        xml.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
        var documento = xml.newDocumentBuilder().parse("entrada.xml");
        System.out.println("Materiales XML: " + documento.getElementsByTagName("material").getLength());
        var salida = materiales.stream().map(m -> m.codigo().equals("MAT-02")
                ? new Material(m.codigo(), m.categoria(), 4) : m).toList();
        var fichero = Path.of("salida.json").toFile();
        mapper.writerWithDefaultPrettyPrinter().writeValue(fichero, salida);
        var recuperados = List.of(mapper.readValue(fichero, Material[].class));
        System.out.println("Aula: " + recuperados.stream().filter(m -> "aula".equals(m.categoria()))
                .mapToInt(Material::cantidad).sum());
    }
}
