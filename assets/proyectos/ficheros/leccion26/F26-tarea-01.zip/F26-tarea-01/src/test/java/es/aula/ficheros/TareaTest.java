package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class TareaTest {
    @Test
    void verificaContrato(@TempDir Path carpeta) throws Exception {
        Path ruta = carpeta.resolve("entrada.txt");
        Tarea.exportar(ruta, List.of("A & B"))
        var doc = javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(ruta.toFile())
        assertEquals("catalogo", doc.getDocumentElement().getTagName())
        assertEquals("A & B", doc.getElementsByTagName("nombre").item(0).getTextContent());
    }
}
