package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

public final class Tarea {
    public static List<String> importar(Path fichero) throws IOException {
        throw new UnsupportedOperationException("Implementa la operación del README");
    }
}
