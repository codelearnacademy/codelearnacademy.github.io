package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class TareaTest {
    @Test
    void verificaContrato(@TempDir Path carpeta) throws Exception {
        Path ruta = carpeta.resolve("entrada.txt");
        Tarea.exportar(ruta, "Cable, azul", 3.5)
        String csv = Files.readString(ruta)
        assertTrue(csv.startsWith("id,nombre,precio"))
        assertTrue(csv.contains("1,\"Cable, azul\",3.5"));
    }
}
