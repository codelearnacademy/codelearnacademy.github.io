package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

public final class Tarea {
    public static void exportar(Path fichero, String nombre, double precio) throws IOException {
        throw new UnsupportedOperationException("Implementa la operación del README");
    }
}
