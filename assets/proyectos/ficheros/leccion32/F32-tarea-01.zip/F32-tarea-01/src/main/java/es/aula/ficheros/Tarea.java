package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

public final class Tarea {
    public static Path resolver(Path configuracion) throws IOException {
        throw new UnsupportedOperationException("Implementa la operación del README");
    }
}
