package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class TareaTest {
    @Test
    void verificaContrato(@TempDir Path carpeta) throws Exception {
        Path ruta = carpeta.resolve("entrada.txt");
        Files.writeString(ruta, "repository.type=json\nrepository.path=datos/catalogo.json\n")
        assertEquals(carpeta.resolve("datos/catalogo.json").toAbsolutePath().normalize(), Tarea.resolver(ruta))
        Files.writeString(ruta, "repository.type=yaml\nrepository.path=datos/a\n")
        assertThrows(IllegalArgumentException.class, () -> Tarea.resolver(ruta));
    }
}
