package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class TareaTest {
    @Test
    void verificaContrato(@TempDir Path carpeta) throws Exception {
        Path ruta = carpeta.resolve("entrada.txt");
        assertEquals("2:Ratón:5.0", Tarea.ficha(2, "Ratón", 5))
        assertThrows(IllegalArgumentException.class, () -> Tarea.ficha(0, "", -1))
        assertThrows(IllegalArgumentException.class, () -> Tarea.ficha(1, "A", Double.NaN));
    }
}
