package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class TareaTest {
    @Test
    void verificaContrato(@TempDir Path carpeta) throws Exception {
        Path ruta = carpeta.resolve("entrada.txt");
        Files.writeString(ruta, "<catalogo/>")
        assertNull(Tarea.cambiar(ruta, "1", "Cable"))
        assertEquals("Cable", Tarea.cambiar(ruta, "1", "Otro"))
        assertEquals("Otro", Tarea.cambiar(ruta, "1", null))
        var doc = javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(ruta.toFile())
        assertEquals(0, doc.getElementsByTagName("producto").getLength());
    }
}
