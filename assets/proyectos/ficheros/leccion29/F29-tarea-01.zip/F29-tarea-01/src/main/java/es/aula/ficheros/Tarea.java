package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

public final class Tarea {
    public static boolean equivalentes(java.util.Map<Integer, String> a, java.util.Map<Integer, String> b) throws IOException {
        throw new UnsupportedOperationException("Implementa la operación del README");
    }
}
