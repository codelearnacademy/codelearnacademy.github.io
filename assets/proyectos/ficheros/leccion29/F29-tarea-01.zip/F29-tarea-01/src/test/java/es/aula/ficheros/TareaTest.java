package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class TareaTest {
    @Test
    void verificaContrato(@TempDir Path carpeta) throws Exception {
        Path ruta = carpeta.resolve("entrada.txt");
        assertTrue(Tarea.equivalentes(java.util.Map.of(1,"A",2,"B"),java.util.Map.of(2,"B",1,"A")))
        assertFalse(Tarea.equivalentes(java.util.Map.of(1,"A"),java.util.Map.of(1,"Otro")));
    }
}
