# F29-tarea-01 · Comparar dos implementaciones

![Encargo del microproyecto](infografia.webp)

## Qué debes implementar

Compara dos inventarios por ID y contenido, independientemente del orden. Devuelve true solo si contienen las mismas asociaciones.

Implementa `boolean equivalentes(java.util.Map<Integer, String> a, java.util.Map<Integer, String> b)` en `src/main/java/es/aula/ficheros/Tarea.java` y conserva su firma. El código inicial está pendiente. Usa llaves `{}` en todos los bloques de control, incluso cuando solo tengan una instrucción.

## Datos y comprobación

Mismas asociaciones en distinto orden, y un caso con un valor reemplazado.

**Resultado esperado:** Datos iguales: true; cambiado: false.

Abre el `pom.xml` en el IDE con JDK 21. Desde la carpeta que contiene el POM ejecuta:

```bash
mvn test
```

La prueba prepara datos temporales cuando necesita ficheros. Fallará mientras la operación esté pendiente. Ejecuta de nuevo después de corregir el código. Si una ejecución manual no encuentra un fichero, registra el directorio de trabajo, la ruta relativa y la ruta absoluta normalizada antes de cambiar el programa.

## Documentación y entrega

Escribe Javadoc para la clase, el método principal de la tarea y los auxiliares que crees. Indica el contrato, los parámetros con `@param`, el resultado con `@return` si procede y los errores con `@throws`. Explica cuándo modifica un fichero y qué estado conserva al fallar. Genera la documentación con `mvn javadoc:javadoc`.

Entrega código, pruebas y una comprobación adicional. Usa un dato distinto o un caso límite y anota el resultado esperado y observado.
