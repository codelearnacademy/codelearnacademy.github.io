package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class TareaTest {
    @Test
    void verificaContrato(@TempDir Path carpeta) throws Exception {
        Path ruta = carpeta.resolve("entrada.txt");
        Files.writeString(ruta, "[]")
        assertEquals(0, Tarea.contar(ruta))
        Files.writeString(ruta, "[{\"id\":1}]")
        assertEquals(1, Tarea.contar(ruta))
        Files.writeString(ruta, "{}")
        assertThrows(IOException.class, () -> Tarea.contar(ruta));
    }
}
