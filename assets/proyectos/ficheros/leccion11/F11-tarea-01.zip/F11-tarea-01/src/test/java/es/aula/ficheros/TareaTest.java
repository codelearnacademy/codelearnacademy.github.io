package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class TareaTest {
    @Test
    void verificaContrato(@TempDir Path carpeta) throws Exception {
        Path ruta = carpeta.resolve("entrada.txt");
        Files.writeString(ruta, "id,nombre\n")
        assertNull(Tarea.cambiar(ruta, 1, "Cable"))
        assertEquals("Cable", Tarea.cambiar(ruta, 1, "Ratón"))
        assertEquals("Ratón", Tarea.cambiar(ruta, 1, null))
        assertEquals(1, Files.readAllLines(ruta).size());
    }
}
