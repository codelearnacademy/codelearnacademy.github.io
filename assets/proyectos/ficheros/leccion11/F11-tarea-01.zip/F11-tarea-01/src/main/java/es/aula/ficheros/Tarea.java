package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

public final class Tarea {
    public static String cambiar(Path fichero, int id, String nombre) throws IOException {
        throw new UnsupportedOperationException("Implementa la operación del README");
    }
}
