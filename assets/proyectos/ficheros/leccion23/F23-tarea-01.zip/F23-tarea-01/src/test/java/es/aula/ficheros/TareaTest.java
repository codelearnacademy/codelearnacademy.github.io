package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class TareaTest {
    @Test
    void verificaContrato(@TempDir Path carpeta) throws Exception {
        Path ruta = carpeta.resolve("entrada.txt");
        Files.writeString(ruta, "<catalogo><producto/></catalogo>")
        assertEquals("catalogo", Tarea.raiz(ruta))
        Files.writeString(ruta, "<catalogo>")
        assertThrows(IOException.class, () -> Tarea.raiz(ruta));
    }
}
