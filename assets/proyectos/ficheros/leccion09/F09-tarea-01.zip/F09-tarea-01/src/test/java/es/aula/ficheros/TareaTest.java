package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class TareaTest {
    @Test
    void verificaContrato(@TempDir Path carpeta) throws Exception {
        Path ruta = carpeta.resolve("entrada.txt");
        Files.writeString(ruta, "id,nombre,precio\n1,Cable,2.5\n2,Ratón,8\n")
        assertEquals(List.of(2.5, 8.0), Tarea.precios(ruta))
        Files.writeString(ruta, "id,nombre,precio\n1,Cable,no\n")
        assertThrows(IllegalArgumentException.class, () -> Tarea.precios(ruta));
    }
}
