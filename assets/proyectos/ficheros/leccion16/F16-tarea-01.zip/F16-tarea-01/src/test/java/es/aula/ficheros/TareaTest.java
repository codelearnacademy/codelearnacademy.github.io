package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class TareaTest {
    @Test
    void verificaContrato(@TempDir Path carpeta) throws Exception {
        Path ruta = carpeta.resolve("entrada.txt");
        Files.writeString(ruta, "id,nombre\n")
        Tarea.alta(ruta, 1, "Cable")
        assertThrows(IllegalArgumentException.class, () -> Tarea.alta(ruta, 1, "Otro"))
        assertEquals(List.of("id,nombre", "1,Cable"), Files.readAllLines(ruta));
    }
}
