package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

public final class Tarea {
    public static java.util.Optional<String> buscar(java.util.Map<String, String> vehiculos, String matricula) throws IOException {
        throw new UnsupportedOperationException("Implementa la operación del README");
    }
}
