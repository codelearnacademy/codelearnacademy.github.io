package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class TareaTest {
    @Test
    void verificaContrato(@TempDir Path carpeta) throws Exception {
        Path ruta = carpeta.resolve("entrada.txt");
        var datos = java.util.Map.of("1234ABC", "Corolla")
        assertEquals(java.util.Optional.of("Corolla"), Tarea.buscar(datos, "1234ABC"))
        assertTrue(Tarea.buscar(datos, "9999XYZ").isEmpty());
    }
}
