package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class TareaTest {
    @Test
    void verificaContrato(@TempDir Path carpeta) throws Exception {
        Path ruta = carpeta.resolve("entrada.txt");
        var ids = new java.util.ArrayList<>(List.of(1))
        assertThrows(IllegalStateException.class, () -> Tarea.alta(ids, 2, copia -> { throw new IllegalStateException(); }))
        assertEquals(List.of(1), ids)
        assertEquals(List.of(1, 2), Tarea.alta(ids, 2, copia -> { assertEquals(List.of(1, 2), copia); }))
        assertEquals(List.of(1), ids);
    }
}
