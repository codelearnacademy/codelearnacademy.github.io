package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

public final class Tarea {
    public static List<Integer> alta(List<Integer> ids, int id, java.util.function.Consumer<List<Integer>> guardar) throws IOException {
        throw new UnsupportedOperationException("Implementa la operación del README");
    }
}
