package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class TareaTest {
    @Test
    void verificaContrato(@TempDir Path carpeta) throws Exception {
        Path ruta = carpeta.resolve("entrada.txt");
        Files.writeString(ruta, "matricula\n1234ABC\n")
        assertEquals("1234ABC", Tarea.matricula(ruta, "csv"))
        Files.writeString(ruta, "{\"matricula\":\"1234ABC\"}")
        assertEquals("1234ABC", Tarea.matricula(ruta, "json"))
        Files.writeString(ruta, "<vehiculo><matricula>1234ABC</matricula></vehiculo>")
        assertEquals("1234ABC", Tarea.matricula(ruta, "xml"));
    }
}
