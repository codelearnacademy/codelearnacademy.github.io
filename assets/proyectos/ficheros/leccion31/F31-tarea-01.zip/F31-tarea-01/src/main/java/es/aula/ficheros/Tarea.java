package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

public final class Tarea {
    public static String matricula(Path fichero, String formato) throws IOException {
        throw new UnsupportedOperationException("Implementa la operación del README");
    }
}
