package es.aula.ficheros;

import java.nio.file.Path;

public class Main {
    public static void main(String[] args) throws Exception {
        Path base = Path.of("").toAbsolutePath();
        String entrada = args.length == 0 ? "datos/entrada.txt" : args[0];
        System.out.println("Directorio de trabajo: " + base);
        System.out.println("Ruta recibida: " + entrada);
        System.out.println("Ruta comprobada: " + base.resolve(entrada).normalize());
        System.out.println(Tarea.diagnosticar(base, entrada));
    }
}
