package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

public final class Tarea {
    public static String diagnosticar(Path base, String entrada) throws IOException {
        throw new UnsupportedOperationException("Implementa la operación del README");
    }
}
