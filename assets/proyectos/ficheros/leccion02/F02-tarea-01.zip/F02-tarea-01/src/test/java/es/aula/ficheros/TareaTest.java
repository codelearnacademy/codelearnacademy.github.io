package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class TareaTest {
    @Test
    void verificaContrato(@TempDir Path carpeta) throws Exception {
        Path ruta = carpeta.resolve("entrada.txt");
        Files.writeString(ruta, "dato")
        Files.createDirectory(carpeta.resolve("datos"))
        assertEquals("FICHERO", Tarea.diagnosticar(carpeta, "datos/../entrada.txt"))
        assertEquals("CARPETA", Tarea.diagnosticar(carpeta, "datos"))
        assertEquals("AUSENTE", Tarea.diagnosticar(carpeta, "ausente.txt"))
        assertEquals("FICHERO", Tarea.diagnosticar(carpeta, ruta.toString()));
    }
}
