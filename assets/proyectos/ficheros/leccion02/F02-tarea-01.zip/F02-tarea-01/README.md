# F02-tarea-01 · Localizar el fichero

![Encargo del microproyecto](infografia.webp)

## Qué debes implementar

Resuelve la ruta recibida respecto a la carpeta base y normalízala. Devuelve FICHERO, CARPETA, AUSENTE u OTRO según su tipo. Propaga IOException cuando no puedas comprobar los atributos.

Implementa `String diagnosticar(Path base, String entrada)` en `src/main/java/es/aula/ficheros/Tarea.java` y conserva su firma. El código inicial está pendiente. Usa llaves `{}` en todos los bloques de control, incluso cuando solo tengan una instrucción.

## Datos y comprobación

Crea datos/entrada.txt. Desde la raíz, compara datos/entrada.txt, datos y un nombre inexistente. Imprime también la base y la ruta normalizada.

**Resultado esperado:** FICHERO · CARPETA · AUSENTE.

Abre el `pom.xml` en el IDE con JDK 21. Desde la carpeta que contiene el POM ejecuta:

```bash
mvn test
```

La prueba prepara datos temporales cuando necesita ficheros. Fallará mientras la operación esté pendiente. Ejecuta de nuevo después de corregir el código. Si una ejecución manual no encuentra un fichero, registra el directorio de trabajo, la ruta relativa y la ruta absoluta normalizada antes de cambiar el programa.

### Comprueba desde dónde busca Java

Cuando hayas implementado el método, ejecuta estos comandos desde la carpeta del POM.

```bash
mvn compile
java -cp target/classes es.aula.ficheros.Main datos/entrada.txt
java -cp target/classes es.aula.ficheros.Main datos
java -cp target/classes es.aula.ficheros.Main datos/falta.txt
cd datos
java -cp ../target/classes es.aula.ficheros.Main entrada.txt
```

Compara las tres primeras salidas con el contrato. La última llamada debe encontrar el mismo fichero que la primera, aunque cambien el directorio de trabajo y la ruta relativa.

## Documentación y entrega

Escribe Javadoc para la clase, el método principal de la tarea y los auxiliares que crees. Indica el contrato, los parámetros con `@param`, el resultado con `@return` si procede y los errores con `@throws`. Explica cuándo modifica un fichero y qué estado conserva al fallar. Genera la documentación con `mvn javadoc:javadoc`.

Entrega código, pruebas y una comprobación adicional. Usa un dato distinto o un caso límite y anota el resultado esperado y observado.
