package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

public final class Tarea {
    @FunctionalInterface
    public interface Escritor {
        void escribir(Path fichero, String contenido) throws IOException;
    }

    public static void guardar(Path fichero, String contenido, Escritor escritor) throws IOException {
        throw new UnsupportedOperationException("Implementa la operación del README");
    }
}
