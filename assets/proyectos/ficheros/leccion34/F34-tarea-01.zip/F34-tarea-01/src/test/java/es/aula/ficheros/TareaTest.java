package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class TareaTest {
    @Test
    void verificaContrato(@TempDir Path carpeta) throws Exception {
        Path ruta = carpeta.resolve("entrada.txt");
        Files.writeString(ruta, "anterior")
        assertThrows(IOException.class, () -> Tarea.guardar(ruta, "nuevo", (tmp, texto) -> { Files.writeString(tmp, "parcial"); throw new IOException(); }))
        assertEquals("anterior", Files.readString(ruta))
        try (var lista = Files.list(carpeta)) { assertEquals(1, lista.count()); }
        Tarea.guardar(ruta, "nuevo", (tmp, texto) -> { Files.writeString(tmp, texto); })
        assertEquals("nuevo", Files.readString(ruta));
    }
}
