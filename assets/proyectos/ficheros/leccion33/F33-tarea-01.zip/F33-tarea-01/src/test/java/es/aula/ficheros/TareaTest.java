package es.aula.ficheros;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class TareaTest {
    @Test
    void verificaContrato(@TempDir Path carpeta) throws Exception {
        Path ruta = carpeta.resolve("entrada.txt");
        Files.writeString(ruta, "id,nombre\n1,A\n2,B\n")
        Path destino = carpeta.resolve("catalogo.json")
        assertEquals(2, Tarea.migrar(ruta, destino))
        var json = new com.fasterxml.jackson.databind.ObjectMapper().readTree(destino.toFile())
        assertEquals(2,json.size())
        assertEquals(2,json.get(1).get("id").asInt())
        assertEquals("B",json.get(1).get("nombre").asText());
    }
}
