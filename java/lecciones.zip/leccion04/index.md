---
layout: lesson
route: java
lesson_id: leccion04
lesson_number: "04"
title: Organización de clases
search_title: Lección 04 - Organización de clases
search_description: Organizarás el código en paquetes, clases y responsabilidades claras.
description: Organizarás el código en paquetes, clases y responsabilidades claras.
lessons:
  - id: objetivo
    title: Objetivo
  - id: ejercicios
    title: Ejercicios
permalink: /java/leccion04/
---

## Objetivo

En esta lección trabajarás los conceptos principales de **Organización de clases** mediante explicación, ejemplos y ejercicios.

<div class="cla-note">
<strong>Práctica</strong>
<p>Completa los ejercicios propuestos y conserva el código en tu repositorio local.</p>
</div>

## Ejercicios

- Lee la explicación principal.
- Ejecuta los ejemplos.
- Resuelve una pequeña práctica incremental.
