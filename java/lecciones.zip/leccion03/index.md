---
layout: lesson
route: java
lesson_id: leccion03
lesson_number: "03"
title: Estructuras de control
search_title: Lección 03 - Estructuras de control
search_description: Practicarás estructuras condicionales y repetitivas para controlar el flujo de ejecución.
description: Practicarás estructuras condicionales y repetitivas para controlar el flujo de ejecución.
lessons:
  - id: objetivo
    title: Objetivo
  - id: ejercicios
    title: Ejercicios
permalink: /java/leccion03/
---

## Objetivo

En esta lección trabajarás los conceptos principales de **Estructuras de control** mediante explicación, ejemplos y ejercicios.

<div class="cla-note">
<strong>Práctica</strong>
<p>Completa los ejercicios propuestos y conserva el código en tu repositorio local.</p>
</div>

## Ejercicios

- Lee la explicación principal.
- Ejecuta los ejemplos.
- Resuelve una pequeña práctica incremental.
