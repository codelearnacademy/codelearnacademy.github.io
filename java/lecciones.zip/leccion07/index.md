---
layout: lesson
route: java
lesson_id: leccion07
lesson_number: "07"
title: Herencia e interfaces
search_title: Lección 07 - Herencia e interfaces
search_description: Aplicarás herencia, interfaces y polimorfismo para diseñar soluciones extensibles.
description: Aplicarás herencia, interfaces y polimorfismo para diseñar soluciones extensibles.
lessons:
  - id: objetivo
    title: Objetivo
  - id: ejercicios
    title: Ejercicios
permalink: /java/leccion07/
---

## Objetivo

En esta lección trabajarás los conceptos principales de **Herencia e interfaces** mediante explicación, ejemplos y ejercicios.

<div class="cla-note">
<strong>Práctica</strong>
<p>Completa los ejercicios propuestos y conserva el código en tu repositorio local.</p>
</div>

## Ejercicios

- Lee la explicación principal.
- Ejecuta los ejemplos.
- Resuelve una pequeña práctica incremental.
