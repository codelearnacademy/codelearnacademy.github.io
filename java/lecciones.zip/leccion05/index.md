---
layout: lesson
route: java
lesson_id: leccion05
lesson_number: "05"
title: Entrada y salida
search_title: Lección 05 - Entrada y salida
search_description: Trabajarás con entrada y salida de datos en aplicaciones de consola.
description: Trabajarás con entrada y salida de datos en aplicaciones de consola.
lessons:
  - id: objetivo
    title: Objetivo
  - id: ejercicios
    title: Ejercicios
permalink: /java/leccion05/
---

## Objetivo

En esta lección trabajarás los conceptos principales de **Entrada y salida** mediante explicación, ejemplos y ejercicios.

<div class="cla-note">
<strong>Práctica</strong>
<p>Completa los ejercicios propuestos y conserva el código en tu repositorio local.</p>
</div>

## Ejercicios

- Lee la explicación principal.
- Ejecuta los ejemplos.
- Resuelve una pequeña práctica incremental.
