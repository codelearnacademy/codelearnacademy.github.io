---
layout: lesson
route: java
lesson_id: leccion02
lesson_number: "02"
title: Clases y objetos
search_title: Lección 02 - Clases y objetos
search_description: Aprenderás a modelar conceptos mediante clases, objetos, atributos y métodos.
description: Aprenderás a modelar conceptos mediante clases, objetos, atributos y métodos.
lessons:
  - id: clases
    title: Clases
  - id: objetos
    title: Objetos
  - id: constructores
    title: Constructores
permalink: /java/leccion02/
---

## 1. Clases
{: #clases }

Una clase define la estructura y el comportamiento de un tipo de objeto.

## 2. Objetos
{: #objetos }

Un objeto es una instancia concreta de una clase.

## 3. Constructores
{: #constructores }

Los constructores permiten inicializar objetos de forma controlada.