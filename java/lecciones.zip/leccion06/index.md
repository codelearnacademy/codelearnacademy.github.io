---
layout: lesson
route: java
lesson_id: leccion06
lesson_number: "06"
title: Colecciones y tipos avanzados
search_title: Lección 06 - Colecciones y tipos avanzados
search_description: Usarás colecciones y tipos avanzados para modelar datos de forma flexible.
description: Usarás colecciones y tipos avanzados para modelar datos de forma flexible.
lessons:
  - id: objetivo
    title: Objetivo
  - id: ejercicios
    title: Ejercicios
permalink: /java/leccion06/
---

## Objetivo

En esta lección trabajarás los conceptos principales de **Colecciones y tipos avanzados** mediante explicación, ejemplos y ejercicios.

<div class="cla-note">
<strong>Práctica</strong>
<p>Completa los ejercicios propuestos y conserva el código en tu repositorio local.</p>
</div>

## Ejercicios

- Lee la explicación principal.
- Ejecuta los ejemplos.
- Resuelve una pequeña práctica incremental.
