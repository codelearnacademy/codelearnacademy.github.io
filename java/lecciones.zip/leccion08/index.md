---
layout: lesson
route: java
lesson_id: leccion08
lesson_number: "08"
title: Persistencia con SQLite
search_title: Lección 08 - Persistencia con SQLite
search_description: Integrarás SQLite para persistir información en una aplicación Java.
description: Integrarás SQLite para persistir información en una aplicación Java.
lessons:
  - id: objetivo
    title: Objetivo
  - id: ejercicios
    title: Ejercicios
permalink: /java/leccion08/
---

## Objetivo

En esta lección trabajarás los conceptos principales de **Persistencia con SQLite** mediante explicación, ejemplos y ejercicios.

<div class="cla-note">
<strong>Práctica</strong>
<p>Completa los ejercicios propuestos y conserva el código en tu repositorio local.</p>
</div>

## Ejercicios

- Lee la explicación principal.
- Ejecuta los ejemplos.
- Resuelve una pequeña práctica incremental.
