---
layout: lesson
route: java
lesson_id: leccion01
lesson_number: "01"
title: Introducción a Java
search_title: Lección 01 - Introducción a Java
search_description: Conocerás los conceptos fundamentales de Java, la JVM, el JDK y cómo configurar tu entorno de desarrollo.
description: Conocerás los conceptos fundamentales de Java, la JVM, el JDK y cómo configurar tu entorno de desarrollo.
lessons:
  - id: que-es-java
    title: ¿Qué es Java?
  - id: jvm
    title: JVM
  - id: jdk-jre
    title: JDK y JRE
  - id: instalacion
    title: Instalación
  - id: primer-programa
    title: Tu primer programa
permalink: /java/leccion01/
---

## 1. ¿Qué es Java?
{: #que-es-java }

Java es un lenguaje de programación de propósito general, orientado a objetos y diseñado para ejecutarse en diferentes plataformas mediante la JVM.

<div class="cla-note">
<strong>Nota</strong>
<p>Java fue creado por Sun Microsystems y actualmente es mantenido por Oracle y la comunidad OpenJDK.</p>
</div>

## 2. JVM
{: #jvm }

La JVM, o Java Virtual Machine, es la máquina virtual que ejecuta el código bytecode generado por el compilador de Java.

## 3. JDK y JRE
{: #jdk-jre }

- **JDK**: contiene las herramientas necesarias para desarrollar aplicaciones Java.
- **JRE**: contiene lo necesario para ejecutar aplicaciones Java.

## 4. Instalación
{: #instalacion }

Para trabajar con Java debes instalar un JDK compatible y configurar correctamente tu entorno de desarrollo.

## 5. Tu primer programa
{: #primer-programa }

```java
public class Main {
    public static void main(String[] args) {
        System.out.println("Hola, Java");
    }
}
```