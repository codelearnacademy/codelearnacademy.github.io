package aula.tareas;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class TareaControllerTest {
    private static final String API = "/api/tareas";

    @Autowired
    private MockMvc mvc;

    @Test
    void recorreElCicloDeVidaDeUnaTarea() throws Exception {
        mvc.perform(get(API)).andExpect(status().isOk()).andExpect(content().json("[]"));

        String ruta = mvc.perform(post(API).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"titulo\":\"Inicial\"}"))
                .andExpect(status().isCreated())
                .andExpect(header().exists("Location"))
                .andReturn().getResponse().getHeader("Location");

        mvc.perform(put(ruta).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"titulo\":\"Revisar\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.titulo").value("Revisar"));

        mvc.perform(patch(ruta).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"titulo\":\"Final\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.titulo").value("Final"));
        mvc.perform(patch(ruta).contentType(MediaType.APPLICATION_JSON).content("{}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.titulo").value("Final"));

        mvc.perform(delete(ruta)).andExpect(status().isNoContent()).andExpect(content().string(""));
        mvc.perform(get(ruta)).andExpect(status().isNotFound())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
                .andExpect(jsonPath("$.status").value(404));
        mvc.perform(delete(ruta)).andExpect(status().isNotFound());
    }

    @Test
    void identificaElCampoInvalido() throws Exception {
        mvc.perform(post(API).contentType(MediaType.APPLICATION_JSON).content("{\"titulo\":\" \"}"))
                .andExpect(status().isBadRequest())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
                .andExpect(jsonPath("$.errores[0].campo").value("titulo"));
    }

    @Test
    void diferenciaJsonInvalidoMetodoYTipoDeContenido() throws Exception {
        mvc.perform(post(API).contentType(MediaType.APPLICATION_JSON).content("{"))
                .andExpect(status().isBadRequest());
        mvc.perform(delete(API)).andExpect(status().isMethodNotAllowed())
                .andExpect(header().string("Allow", containsString("GET")));
        mvc.perform(post(API).contentType(MediaType.TEXT_PLAIN).content("Tarea"))
                .andExpect(status().isUnsupportedMediaType());
    }
}
