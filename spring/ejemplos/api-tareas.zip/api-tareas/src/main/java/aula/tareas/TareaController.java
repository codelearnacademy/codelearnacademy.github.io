package aula.tareas;

import java.net.URI;
import java.util.List;
import java.util.Map;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/tareas")
class TareaController {
    private final TareaService servicio;

    TareaController(TareaService servicio) {
        this.servicio = servicio;
    }

    @GetMapping
    List<Tarea> listar() {
        return servicio.listar();
    }

    @GetMapping("/{id}")
    ResponseEntity<Tarea> buscar(@PathVariable("id") long id) {
        return ResponseEntity.ok(exigirTarea(servicio.buscar(id)));
    }

    @PostMapping
    ResponseEntity<Tarea> crear(@Valid @RequestBody NuevaTarea peticion) {
        Tarea tarea = servicio.crear(peticion.titulo());
        return ResponseEntity.created(URI.create("/api/tareas/" + tarea.id())).body(tarea);
    }

    @PutMapping("/{id}")
    ResponseEntity<Tarea> reemplazar(@PathVariable("id") long id, @Valid @RequestBody NuevaTarea peticion) {
        return ResponseEntity.ok(exigirTarea(servicio.actualizar(id, peticion.titulo())));
    }

    @PatchMapping("/{id}")
    ResponseEntity<Tarea> modificar(@PathVariable("id") long id, @RequestBody Map<String, Object> cambios) {
        if (cambios.isEmpty()) {
            return ResponseEntity.ok(exigirTarea(servicio.buscar(id)));
        }

        if (cambios.size() != 1 || !(cambios.get("titulo") instanceof String titulo) || titulo.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Envía un objeto vacío o un título de texto no vacío como único campo.");
        }

        return ResponseEntity.ok(exigirTarea(servicio.actualizar(id, titulo)));
    }

    @DeleteMapping("/{id}")
    ResponseEntity<Void> eliminar(@PathVariable("id") long id) {
        if (servicio.eliminar(id)) {
            return ResponseEntity.noContent().build();
        }
        throw tareaNoEncontrada();
    }

    private Tarea exigirTarea(Tarea tarea) {
        if (tarea == null) {
            throw tareaNoEncontrada();
        }
        return tarea;
    }

    private ResponseStatusException tareaNoEncontrada() {
        return new ResponseStatusException(HttpStatus.NOT_FOUND, "La tarea no existe.");
    }

    public record NuevaTarea(@NotBlank String titulo) {}
}
