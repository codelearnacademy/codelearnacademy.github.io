package aula.tareas;

import java.util.Map;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestControllerAdvice
class ErroresRest extends ResponseEntityExceptionHandler {
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException error, HttpHeaders headers,
            HttpStatusCode status, WebRequest request) {
        var campos = error.getBindingResult().getFieldErrors().stream()
                .map(campo -> Map.of(
                        "campo", campo.getField(),
                        "mensaje", String.valueOf(campo.getDefaultMessage())))
                .toList();
        var problema = ProblemDetail.forStatusAndDetail(status, "Revisa los campos indicados.");
        problema.setProperty("errores", campos);
        return handleExceptionInternal(error, problema, headers, status, request);
    }
}
