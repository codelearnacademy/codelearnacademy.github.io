# API de tareas con Spring Boot

Necesitas JDK 21 y Maven. Desde el directorio que contiene `pom.xml`, ejecuta:

```sh
mvn spring-boot:run
```

La documentación interactiva está en [Swagger UI](http://localhost:8080/swagger-ui/index.html).

| Ruta base | Almacenamiento |
| --- | --- |
| `/api/memory/tareas` | Memoria, independiente de CSV, JSON y SQLite |
| `/api/csv/tareas` | Fichero CSV del proyecto |
| `/api/json/tareas` | Fichero JSON del proyecto |
| `/api/jdbc/tareas` | SQLite, tabla `tareas_jdbc`, consultas SQL parametrizadas con `JdbcTemplate` |
| `/api/orm/tareas` | SQLite, tabla `tareas_orm`, Spring Data JPA e Hibernate |

El ZIP incluye `data/tareas.sqlite3` con las dos tablas vacías. Si falta el archivo, la aplicación lo crea y ejecuta `src/main/resources/schema.sql` al arrancar. Cada tabla tiene su propia numeración y sus propios registros. Las rutas CSV y JSON conservan el comportamiento del proyecto original.

Las tareas en memoria se pierden al reiniciar la aplicación.

## CRUD de Memory, JDBC y ORM

| Método | Ruta relativa | Respuesta |
| --- | --- | --- |
| GET | Ruta base | `200` con la lista |
| GET | `/{id}` | `200` con la tarea o `404` |
| POST | Ruta base | `201` con la tarea y cabecera `Location` |
| PUT | `/{id}` | `200` con la tarea actualizada o `404` |
| DELETE | `/{id}` | `204` o `404` |

POST y PUT reciben un objeto como `{"titulo":"Preparar entrega"}`. Un título ausente o en blanco devuelve `400`. El repositorio genera el identificador.

```sh
BASE=http://localhost:8080/api/jdbc/tareas
curl -i "$BASE"
curl -i -H 'Content-Type: application/json' -d '{"titulo":"Preparar entrega"}' "$BASE"

# Usa el id devuelto por el POST. En una tabla nueva será 1.
curl -i "$BASE/1"
curl -i -X PUT -H 'Content-Type: application/json' -d '{"titulo":"Revisar entrega"}' "$BASE/1"
curl -i -X DELETE "$BASE/1"
curl -i "$BASE/1"
```

Para probar memoria u ORM, repite la secuencia con `BASE=http://localhost:8080/api/memory/tareas` o `BASE=http://localhost:8080/api/orm/tareas`.

Ejecuta `mvn package` para empaquetar. Desde la raíz del proyecto puedes iniciar el JAR con `java -jar target/tareas-0.0.1.jar`.

## Inspeccionar la base SQLite

Desde la carpeta que contiene `pom.xml`, puedes listar las tablas y ejecutar las consultas de lectura incluidas.

```sh
sqlite3 -readonly data/tareas.sqlite3 ".tables"
sqlite3 -readonly -header -column data/tareas.sqlite3 < data/consultas.sql
```
