package aula.tareas.repository;

import aula.tareas.modelo.Tarea;
import aula.tareas.modelo.TareaEntidad;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public class TareaRepositoryOrm implements ITareaRepository {
    private final TareaRepositoryJpa jpa;

    public TareaRepositoryOrm(TareaRepositoryJpa jpa) {
        this.jpa = jpa;
    }

    @Override
    public Tarea create(String titulo) {
        return jpa.save(new TareaEntidad(titulo)).aTarea();
    }

    @Override
    @Transactional
    public boolean delete(long id) {
        var entidad = jpa.findById(id);
        entidad.ifPresent(jpa::delete);
        return entidad.isPresent();
    }

    @Override
    public List<Tarea> findAll() {
        return jpa.findAll(Sort.by("id")).stream().map(TareaEntidad::aTarea).toList();
    }

    @Override
    public Tarea findById(long id) {
        return jpa.findById(id).map(TareaEntidad::aTarea).orElse(null);
    }

    @Override
    @Transactional
    public Tarea update(Tarea tarea) {
        return jpa.findById(tarea.id()).map(entidad -> {
            entidad.cambiarTitulo(tarea.titulo());
            return entidad.aTarea();
        }).orElse(null);
    }
}
