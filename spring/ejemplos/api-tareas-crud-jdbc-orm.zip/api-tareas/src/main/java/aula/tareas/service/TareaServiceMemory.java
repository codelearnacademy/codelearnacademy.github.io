package aula.tareas.service;

import aula.tareas.repository.TareaRepository;
import org.springframework.stereotype.Service;

@Service
public class TareaServiceMemory extends TareaServiceCrud {
    public TareaServiceMemory(TareaRepository repository) {
        super(repository);
    }
}
