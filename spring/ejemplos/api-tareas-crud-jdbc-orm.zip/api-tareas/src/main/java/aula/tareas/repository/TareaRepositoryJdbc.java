package aula.tareas.repository;

import aula.tareas.modelo.Tarea;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class TareaRepositoryJdbc implements ITareaRepository {
    private static final RowMapper<Tarea> MAPEAR_TAREA =
            (fila, numero) -> new Tarea(fila.getLong("id"), fila.getString("titulo"));

    private final JdbcTemplate jdbc;

    public TareaRepositoryJdbc(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public Tarea create(String titulo) {
        return jdbc.queryForObject(
                "INSERT INTO tareas_jdbc (titulo) VALUES (?) RETURNING id, titulo",
                MAPEAR_TAREA, titulo);
    }

    @Override
    public boolean delete(long id) {
        return jdbc.update("DELETE FROM tareas_jdbc WHERE id = ?", id) != 0;
    }

    @Override
    public List<Tarea> findAll() {
        return jdbc.query("SELECT id, titulo FROM tareas_jdbc ORDER BY id", MAPEAR_TAREA);
    }

    @Override
    public Tarea findById(long id) {
        return jdbc.query("SELECT id, titulo FROM tareas_jdbc WHERE id = ?", MAPEAR_TAREA, id)
                .stream().findFirst().orElse(null);
    }

    @Override
    public Tarea update(Tarea tarea) {
        return jdbc.query(
                "UPDATE tareas_jdbc SET titulo = ? WHERE id = ? RETURNING id, titulo",
                MAPEAR_TAREA, tarea.titulo(), tarea.id()).stream().findFirst().orElse(null);
    }
}
