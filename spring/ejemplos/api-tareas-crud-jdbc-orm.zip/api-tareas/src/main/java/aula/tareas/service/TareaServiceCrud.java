package aula.tareas.service;

import aula.tareas.modelo.Tarea;
import aula.tareas.repository.ITareaRepository;

import java.util.List;

public abstract class TareaServiceCrud implements ITareaService {
    private final ITareaRepository repository;

    protected TareaServiceCrud(ITareaRepository repository) {
        this.repository = repository;
    }

    @Override
    public List<Tarea> listar() {
        return repository.findAll();
    }

    @Override
    public Tarea buscar(long id) {
        return repository.findById(id);
    }

    @Override
    public Tarea crear(String titulo) {
        return repository.create(titulo);
    }

    public Tarea actualizar(long id, String titulo) {
        return repository.update(new Tarea(id, titulo));
    }

    public boolean eliminar(long id) {
        return repository.delete(id);
    }
}
