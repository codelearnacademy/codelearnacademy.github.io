package aula.tareas.repository;

import aula.tareas.modelo.TareaEntidad;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TareaRepositoryJpa extends JpaRepository<TareaEntidad, Long> {
}
