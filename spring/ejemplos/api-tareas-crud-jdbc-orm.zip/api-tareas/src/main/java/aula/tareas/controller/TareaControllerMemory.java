package aula.tareas.controller;

import aula.tareas.service.TareaServiceMemory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/memory/tareas")
public class TareaControllerMemory extends TareaControllerCrud {
    public TareaControllerMemory(TareaServiceMemory servicio) {
        super(servicio);
    }
}
