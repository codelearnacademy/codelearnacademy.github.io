package aula.tareas.controller;

import aula.tareas.service.TareaServiceOrm;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/orm/tareas")
public class TareaControllerOrm extends TareaControllerCrud {
    public TareaControllerOrm(TareaServiceOrm servicio) {
        super(servicio);
    }
}
