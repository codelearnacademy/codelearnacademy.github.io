package aula.tareas.controller;

import aula.tareas.service.TareaServiceJdbc;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/jdbc/tareas")
public class TareaControllerJdbc extends TareaControllerCrud {
    public TareaControllerJdbc(TareaServiceJdbc servicio) {
        super(servicio);
    }
}
