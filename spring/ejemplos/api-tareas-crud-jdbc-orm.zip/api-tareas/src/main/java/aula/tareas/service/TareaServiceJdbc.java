package aula.tareas.service;

import aula.tareas.repository.TareaRepositoryJdbc;
import org.springframework.stereotype.Service;

@Service
public class TareaServiceJdbc extends TareaServiceCrud {
    public TareaServiceJdbc(TareaRepositoryJdbc repository) {
        super(repository);
    }
}
