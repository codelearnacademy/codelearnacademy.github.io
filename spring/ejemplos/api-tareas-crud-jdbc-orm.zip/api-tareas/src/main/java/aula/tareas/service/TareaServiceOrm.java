package aula.tareas.service;

import aula.tareas.repository.TareaRepositoryOrm;
import org.springframework.stereotype.Service;

@Service
public class TareaServiceOrm extends TareaServiceCrud {
    public TareaServiceOrm(TareaRepositoryOrm repository) {
        super(repository);
    }
}
