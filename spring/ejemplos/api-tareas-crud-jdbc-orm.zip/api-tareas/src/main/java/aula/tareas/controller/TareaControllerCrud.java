package aula.tareas.controller;

import aula.tareas.modelo.Tarea;
import aula.tareas.service.TareaServiceCrud;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.util.List;

public abstract class TareaControllerCrud {
    private final TareaServiceCrud servicio;

    protected TareaControllerCrud(TareaServiceCrud servicio) {
        this.servicio = servicio;
    }

    @GetMapping
    public List<Tarea> listar() {
        return servicio.listar();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Tarea> buscar(@PathVariable long id) {
        return ResponseEntity.ofNullable(servicio.buscar(id));
    }

    @PostMapping
    public ResponseEntity<Tarea> crear(@Valid @RequestBody PeticionTarea peticion) {
        Tarea tarea = servicio.crear(peticion.titulo());
        var ubicacion = ServletUriComponentsBuilder.fromCurrentRequestUri()
                .path("/{id}").buildAndExpand(tarea.id()).toUri();
        return ResponseEntity.created(ubicacion).body(tarea);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Tarea> actualizar(@PathVariable long id, @Valid @RequestBody PeticionTarea peticion) {
        return ResponseEntity.ofNullable(servicio.actualizar(id, peticion.titulo()));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable long id) {
        if (servicio.eliminar(id)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    public record PeticionTarea(@NotBlank String titulo) {}
}
