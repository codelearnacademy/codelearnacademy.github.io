package aula.tareas.modelo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tareas_orm")
public class TareaEntidad {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String titulo;

    protected TareaEntidad() {
    }

    public TareaEntidad(String titulo) {
        this.titulo = titulo;
    }

    public void cambiarTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Tarea aTarea() {
        return new Tarea(id, titulo);
    }
}
