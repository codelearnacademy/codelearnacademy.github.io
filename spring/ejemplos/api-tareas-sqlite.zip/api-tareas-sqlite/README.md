# Entidades y persistencia con SQLite3

Práctica de las lecciones 61–67. Requisitos: JDK 21, Maven y el cliente `sqlite3` para inspeccionar el archivo desde la terminal.

## Arrancar y consultar una fila

```sh
mvn test
mvn spring-boot:run
```

Flyway aplica V1 y V2 al archivo `tareas-practica.sqlite3` en el directorio del proyecto. V1 incluye la categoría «Estudio» y una tarea. En una segunda terminal, ejecuta:

```sh
sqlite3 -readonly tareas-practica.sqlite3 'SELECT id, nombre FROM categorias;'
curl -i -H 'Content-Type: application/json' --data '{"titulo":"Repasar JPA","categoriaId":1}' http://localhost:8080/api/tareas
sqlite3 -readonly tareas-practica.sqlite3 'SELECT id, titulo, categoria_id, estado FROM tareas;'
```

Usa el ID de «Estudio» devuelto por la primera consulta. Espera `201` con `Location`. Sigue esa ruta con GET y compara el JSON con la fila SQL. Repite POST con una categoría inexistente y espera `404`.

## Comprobar la clave foránea

```sh
sqlite3 -bail tareas-practica.sqlite3 <<'SQL'
PRAGMA foreign_keys = ON;
INSERT INTO tareas(titulo, categoria_id) VALUES ('Invalida', -1);
SQL
```

Espera un error de clave foránea. Hikari activa la misma opción en cada conexión de la aplicación. La consola SQLite necesita activarla para su propia conexión.

## Comprobar un rollback

```sh
mvn -Dtest=PersistenciaSqliteTest#revierteLaInsercionSiLaOperacionFalla test
```

La prueba usa un archivo temporal. Inserta una tarea, verifica que aparece dentro de la transacción, simula un fallo y vuelve a consultar después del rollback.

## Observar el paso de V1 a V2

Detén la aplicación anterior. Usa un nombre de archivo nuevo para aislar la práctica. El primer arranque utiliza V1 y desactiva temporalmente la validación de Hibernate, porque el código actual ya espera la columna que introduce V2.

```sh
mvn spring-boot:run -Dspring-boot.run.arguments="--spring.datasource.url=jdbc:sqlite:tareas-migracion.sqlite3 --spring.flyway.target=1 --spring.jpa.hibernate.ddl-auto=none --spring.main.web-application-type=none"
sqlite3 -readonly tareas-migracion.sqlite3 'PRAGMA table_info(tareas); SELECT id, titulo FROM tareas;'
mvn spring-boot:run -Dspring-boot.run.arguments="--spring.datasource.url=jdbc:sqlite:tareas-migracion.sqlite3 --spring.main.web-application-type=none"
sqlite3 -readonly tareas-migracion.sqlite3 'SELECT id, titulo, estado FROM tareas; SELECT version, success FROM flyway_schema_history ORDER BY installed_rank;'
```

Comprueba que la tarea de V1 conserva su ID y su título y que ahora tiene estado `PENDIENTE`. SQLite asigna el valor por defecto a las filas existentes al añadir la columna. Las filas nuevas quedan sujetas al `NOT NULL` y al `CHECK` de V2.
