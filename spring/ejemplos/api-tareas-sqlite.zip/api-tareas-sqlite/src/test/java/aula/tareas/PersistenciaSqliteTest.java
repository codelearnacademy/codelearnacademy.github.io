package aula.tareas;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.transaction.support.TransactionTemplate;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
class PersistenciaSqliteTest {
    private static final Path BASE = crearBaseTemporal();

    @Autowired
    private JdbcTemplate jdbc;

    @Autowired
    private TransactionTemplate transacciones;

    @Autowired
    private TareaService servicio;

    @DynamicPropertySource
    static void configurarBase(DynamicPropertyRegistry registro) {
        registro.add("spring.datasource.url", () -> "jdbc:sqlite:" + BASE.toAbsolutePath());
    }

    private static Path crearBaseTemporal() {
        try {
            Path archivo = Files.createTempFile("tareas-test-", ".sqlite3");
            archivo.toFile().deleteOnExit();
            return archivo;
        } catch (IOException error) {
            throw new IllegalStateException("No se pudo preparar la base de pruebas.", error);
        }
    }

    @Test
    void conservaLaTareaDeV1AlAplicarV2() {
        assertEquals("PENDIENTE", jdbc.queryForObject(
                "SELECT estado FROM tareas WHERE titulo = 'Tarea anterior a V2'", String.class));
    }

    @Test
    void sqliteRechazaUnaCategoriaInexistente() {
        assertThrows(DataIntegrityViolationException.class, () -> jdbc.update(
                "INSERT INTO tareas(titulo, categoria_id) VALUES (?, ?)", "Tarea inválida", -1));
    }

    @Test
    void revierteLaInsercionSiLaOperacionFalla() {
        Long categoria = jdbc.queryForObject(
                "SELECT id FROM categorias WHERE nombre = 'Estudio'", Long.class);

        assertThrows(IllegalStateException.class, () -> transacciones.executeWithoutResult(estado -> {
            servicio.crear("Tarea revertida", categoria);
            assertEquals(1L, contarTareasRevertidas());
            throw new IllegalStateException("Fallo simulado después de guardar");
        }));

        assertEquals(0L, contarTareasRevertidas());
    }

    private long contarTareasRevertidas() {
        return jdbc.queryForObject(
                "SELECT COUNT(*) FROM tareas WHERE titulo = 'Tarea revertida'", Long.class);
    }
}
