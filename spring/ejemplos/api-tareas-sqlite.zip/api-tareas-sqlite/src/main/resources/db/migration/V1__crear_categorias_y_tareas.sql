CREATE TABLE categorias (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL UNIQUE
);

CREATE TABLE tareas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    titulo TEXT NOT NULL,
    categoria_id INTEGER NOT NULL REFERENCES categorias(id)
);

CREATE INDEX idx_tareas_categoria ON tareas(categoria_id);

INSERT INTO categorias (nombre) VALUES ('Estudio');
INSERT INTO tareas (titulo, categoria_id)
SELECT 'Tarea anterior a V2', id FROM categorias WHERE nombre = 'Estudio';
