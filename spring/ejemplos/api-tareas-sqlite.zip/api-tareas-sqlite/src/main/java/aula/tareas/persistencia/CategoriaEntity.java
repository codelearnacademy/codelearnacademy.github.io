package aula.tareas.persistencia;

import jakarta.persistence.*;

@Entity
@Table(name = "categorias")
public class CategoriaEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String nombre;

    protected CategoriaEntity() {}

    public Long getId() {
        return id;
    }
}
