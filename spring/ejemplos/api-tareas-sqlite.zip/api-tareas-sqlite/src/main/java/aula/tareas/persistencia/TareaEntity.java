package aula.tareas.persistencia;

import jakarta.persistence.*;

@Entity
@Table(name = "tareas")
public class TareaEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String titulo;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "categoria_id", nullable = false)
    private CategoriaEntity categoria;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Estado estado = Estado.PENDIENTE;

    protected TareaEntity() {}

    public TareaEntity(String titulo, CategoriaEntity categoria) {
        this.titulo = titulo;
        this.categoria = categoria;
    }

    public Long getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public CategoriaEntity getCategoria() {
        return categoria;
    }

    public Estado getEstado() {
        return estado;
    }

    public enum Estado {
        PENDIENTE, COMPLETADA
    }
}
