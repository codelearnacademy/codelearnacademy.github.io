package aula.tareas;

import aula.tareas.persistencia.CategoriaRepository;
import aula.tareas.persistencia.TareaEntity;
import aula.tareas.persistencia.TareaRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
class TareaService {
    private final TareaRepository tareas;
    private final CategoriaRepository categorias;

    TareaService(TareaRepository tareas, CategoriaRepository categorias) {
        this.tareas = tareas;
        this.categorias = categorias;
    }

    @Transactional
    TareaResponse crear(String titulo, long categoriaId) {
        var categoria = categorias.findById(categoriaId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "La categoría no existe."));
        return respuesta(tareas.save(new TareaEntity(titulo.strip(), categoria)));
    }

    @Transactional(readOnly = true)
    TareaResponse buscar(long id) {
        return tareas.findById(id).map(this::respuesta)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "La tarea no existe."));
    }

    private TareaResponse respuesta(TareaEntity tarea) {
        return new TareaResponse(tarea.getId(), tarea.getTitulo(), tarea.getCategoria().getId(), tarea.getEstado());
    }

    record TareaResponse(long id, String titulo, long categoriaId, TareaEntity.Estado estado) {}
}
