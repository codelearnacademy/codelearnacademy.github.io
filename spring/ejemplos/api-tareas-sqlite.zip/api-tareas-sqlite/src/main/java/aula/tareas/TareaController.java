package aula.tareas;

import java.net.URI;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/tareas")
class TareaController {
    private final TareaService servicio;

    TareaController(TareaService servicio) {
        this.servicio = servicio;
    }

    @PostMapping
    ResponseEntity<TareaService.TareaResponse> crear(@Valid @RequestBody NuevaTarea solicitud) {
        var tarea = servicio.crear(solicitud.titulo(), solicitud.categoriaId());
        return ResponseEntity.created(URI.create("/api/tareas/" + tarea.id())).body(tarea);
    }

    @GetMapping("/{id}")
    TareaService.TareaResponse buscar(@PathVariable("id") long id) {
        return servicio.buscar(id);
    }

    record NuevaTarea(@NotBlank String titulo, @NotNull @Positive Long categoriaId) {}
}
