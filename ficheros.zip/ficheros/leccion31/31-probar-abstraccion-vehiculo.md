---
layout: "lesson"
route: "ficheros"
lesson_id: "leccion31"
lesson_file: "31-probar-abstraccion-vehiculo"
lesson_number: "31"
title: "Probar la abstracción con Vehiculo"
description: "Uso de Repository<Vehiculo, String> con CSV, JSON y XML sin cambiar la API CRUD."
permalink: "/ficheros/leccion31/"
---

# Probar la abstracción con otro modelo: `Vehiculo`

## Objetivo

La prueba de una abstracción no es volver a utilizar `Producto`, sino comprobar que funciona con otro dominio y otro tipo de identificador.

```java
public record Vehiculo(
        String matricula,
        String marca,
        String modelo,
        int anio
) {}
```

Ahora el contrato es:

```java
IRepository<Vehiculo, String>
```

frente a:

```java
IRepository<Producto, Long>
```

## Tres ficheros equivalentes

La ruta incluye:

- `data/vehiculos.csv`
- `data/vehiculos.json`
- `data/vehiculos.xml`

Los tres representan los mismos vehículos. El formato cambia; el código consumidor conserva las mismas operaciones.

### CSV

```java
IRepository<Vehiculo, String> repository =
        new VehiculoCsvRepository(Path.of("data", "vehiculos.csv"));
```

### JSON

```java
IRepository<Vehiculo, String> repository =
        new VehiculoJsonRepository(Path.of("data", "vehiculos.json"));
```

### XML

```java
IRepository<Vehiculo, String> repository =
        new VehiculoXmlRepository(Path.of("data", "vehiculos.xml"));
```

Después de instanciarla, la aplicación usa siempre:

```java
repository.findAll();
repository.findById("1234ABC");
repository.create(vehiculo);
repository.update(vehiculo);
repository.delete("1234ABC");
```

<div class="cla-note"><strong>Qué demuestra el ejemplo</strong><p>No hemos abstraído solo el formato: también hemos eliminado el acoplamiento del contrato CRUD a <code>Producto</code> y <code>Long</code>.</p></div>

<div class="cla-lesson-nav"><a href="/ficheros/leccion30/">← 30 · Repository&lt;T, ID&gt;</a><a href="/ficheros/leccion32/">32 · Configuración .properties →</a></div>
